package de.bxmbus.cursorlight;

import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import com.mojang.blaze3d.pipeline.RenderPipeline;

/** Render pipeline for the title-screen glass controls. */
public final class GlassRenderPipelines {
    public static final RenderPipeline SDF_LIQUID_GLASS_BUTTON = RenderPipelines.register(
            RenderPipeline.builder(RenderPipelines.GUI_TEXTURED_SNIPPET)
                    .withLocation(Identifier.fromNamespaceAndPath("cursorlight", "pipeline/sdf_liquid_glass_button"))
                    .withVertexShader(Identifier.fromNamespaceAndPath("cursorlight", "core/liquid_glass_button"))
                    .withFragmentShader(Identifier.fromNamespaceAndPath("cursorlight", "core/liquid_glass_button"))
                    .build());

    public static void initialize() {
        // Force registration before the client compiles its render pipelines.
    }

    private GlassRenderPipelines() {}
}
