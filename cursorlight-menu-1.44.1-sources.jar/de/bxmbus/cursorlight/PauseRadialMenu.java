package de.bxmbus.cursorlight;

import de.bxmbus.cursorlight.mixin.ScreenAccessor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.input.InputWithModifiers;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

/** Replaces the pause-screen button stack with the title screen's radial glass menu. */
public final class PauseRadialMenu {
    public static final String BACK_HITBOX_LABEL = "CURSORLIGHT_BACK_HITBOX";
    private static final Logger LOGGER = LoggerFactory.getLogger("CursorLight/PauseRadialMenu");
    private static final Set<Screen> SCANNED = Collections.newSetFromMap(new WeakHashMap<>());
    private static final Set<Screen> FAILED_LOGGED = Collections.newSetFromMap(new WeakHashMap<>());
    private static final Map<Screen, WeakReference<RadialState>> STATES = new WeakHashMap<>();
    private static final Map<AbstractButton, Integer> RADIAL_SLOTS = new WeakHashMap<>();
    private static final Map<AbstractButton, AbstractButton> PROXY_TARGETS = new WeakHashMap<>();
    private static RadialState activeState;

    private PauseRadialMenu() {}

    public static void reset(Screen screen) {
        SCANNED.remove(screen);
        FAILED_LOGGED.remove(screen);
        WeakReference<RadialState> reference = STATES.remove(screen);
        RadialState state = reference == null ? null : reference.get();
        if (state != null && activeState == state) activeState = null;
        if (state != null) state.clearRadialSlots();
        CursorLightRenderer.radialMenuActive = false;
        CursorLightRenderer.radialMenuContext = 0;
    }

    public static void ensureInstalled(Screen screen, int guiWidth, int guiHeight) {
        if (SCANNED.contains(screen)) {
            RadialState existing = stateFor(screen);
            if (existing != null) {
                activeState = existing;
                existing.updateGuiDimensions(guiWidth, guiHeight);
                existing.activateCurrentPage();
                return;
            }
            SCANNED.remove(screen);
        }

        List<AbstractButton> buttons = visibleButtons(screen);
        List<List<AbstractButton>> rows = groupRows(buttons);
        List<AbstractButton> crowdedRow = rows.stream()
                .filter(row -> row.size() >= 2 && isCrowded(row))
                .max(Comparator.comparingInt((List<AbstractButton> row) -> row.size())).orElse(null);
        List<AbstractButton> excluded = crowdedRow == null ? List.of() : crowdedRow;

        AbstractButton backToGame = find(buttons, excluded, "back to game", "return to game", "resume");
        AbstractButton advancements = find(buttons, excluded, "advancement");
        AbstractButton statistics = find(buttons, excluded, "statistic");
        AbstractButton serverLinks = find(buttons, excluded, "server link", "server links");
        AbstractButton openToLan = find(buttons, excluded, "open to lan", "open to local network",
                "share to lan", "lan");
        AbstractButton options = find(buttons, excluded, "options", "settings");
        AbstractButton disconnect = find(buttons, excluded, "disconnect", "quit to title", "save and quit");
        if (buttons.isEmpty() || (backToGame == null && options == null && disconnect == null)) {
            if (FAILED_LOGGED.add(screen)) {
                LOGGER.warn("Pause radial menu is waiting for its vanilla pause buttons (found {} widgets)",
                        buttons.size());
            }
            return;
        }

        List<AbstractButton> extraSources = new ArrayList<>();
        if (serverLinks != null) extraSources.add(serverLinks);
        if (crowdedRow != null) {
            for (AbstractButton button : crowdedRow) {
                if (!extraSources.contains(button)) extraSources.add(button);
            }
        }

        List<AbstractButton> managed = new ArrayList<>();
        addIfPresent(managed, backToGame);
        addIfPresent(managed, advancements);
        addIfPresent(managed, statistics);
        addIfPresent(managed, openToLan);
        addIfPresent(managed, options);
        addIfPresent(managed, disconnect);
        for (AbstractButton button : extraSources) addIfPresent(managed, button);

        RadialState state = new RadialState(screen, managed);
        state.updateGuiDimensions(guiWidth, guiHeight);
        state.createActionButtons(backToGame, advancements, statistics, openToLan,
                options, disconnect, extraSources);
        for (AbstractButton button : state.radialButtons()) {
            ((ScreenAccessor) (Object) screen).bxmbus$addRenderableWidget(button);
        }
        ((ScreenAccessor) (Object) screen).bxmbus$addRenderableWidget(state.centerBack);
        STATES.put(screen, new WeakReference<>(state));
        SCANNED.add(screen);
        FAILED_LOGGED.remove(screen);
        activeState = state;
        state.showMain();
        LOGGER.info("Installed pause radial menu: six main sectors and {} add-on actions on a second ring page",
                extraSources.size());
        LOGGER.info("Pause radial geometry: gui={}x{}, center=({},{}), quad={}x{}, outerRadius={}, guiScale={}",
                guiWidth, guiHeight, CursorLightRenderer.ringCenterX, CursorLightRenderer.ringCenterY,
                CursorLightRenderer.ringDiameter, CursorLightRenderer.ringDiameter,
                CursorLightRenderer.ringOuterRadius, Minecraft.getInstance().getWindow().getGuiScale());
    }

    public static int radialSlot(AbstractButton button) {
        return RADIAL_SLOTS.getOrDefault(button, -1);
    }

    /** Forward a proxy's real mouse event to the original mod button. */
    public static boolean forwardProxyClick(AbstractButton proxy, MouseButtonEvent event, boolean doubleClick) {
        AbstractButton target = PROXY_TARGETS.get(proxy);
        if (target == null) return false;
        int oldX = target.getX();
        int oldY = target.getY();
        int oldWidth = target.getWidth();
        int oldHeight = target.getHeight();
        boolean oldActive = target.active;
        boolean oldVisible = target.visible;
        target.setRectangle(proxy.getX(), proxy.getY(), proxy.getWidth(), proxy.getHeight());
        target.active = proxy.active;
        target.visible = true;
        try {
            boolean handled = target.mouseClicked(event, doubleClick);
            if (!handled) {
                LOGGER.warn("Original pause button '{}' did not consume its proxy click; invoking its action directly",
                        target.getMessage().getString());
                target.onClick(event, doubleClick);
            }
            LOGGER.info("Forwarded pause radial click to '{}' (handled={})",
                    target.getMessage().getString(), handled);
        } finally {
            target.setRectangle(oldX, oldY, oldWidth, oldHeight);
            target.active = oldActive;
            target.visible = oldVisible;
        }
        return true;
    }

    public static boolean isExtrasPage(Screen screen) {
        RadialState state = stateFor(screen);
        return state != null && state.extrasPage;
    }

    public static boolean isInstalled(Screen screen) {
        return stateFor(screen) != null;
    }

    private static RadialState stateFor(Screen screen) {
        WeakReference<RadialState> reference = STATES.get(screen);
        return reference == null ? null : reference.get();
    }

    private static List<AbstractButton> visibleButtons(Screen screen) {
        List<AbstractButton> buttons = new ArrayList<>();
        for (var child : screen.children()) {
            if (child instanceof AbstractButton button && button.visible) buttons.add(button);
        }
        buttons.sort(Comparator.comparingInt(AbstractButton::getY).thenComparingInt(AbstractButton::getX));
        return buttons;
    }

    private static List<List<AbstractButton>> groupRows(List<AbstractButton> buttons) {
        List<List<AbstractButton>> rows = new ArrayList<>();
        for (AbstractButton button : buttons) {
            List<AbstractButton> row = null;
            int centerY = button.getY() + button.getHeight() / 2;
            for (List<AbstractButton> candidate : rows) {
                int rowCenter = candidate.stream().mapToInt(b -> b.getY() + b.getHeight() / 2).sum()
                        / candidate.size();
                if (Math.abs(centerY - rowCenter) <= Math.max(4, button.getHeight() / 3)) {
                    row = candidate;
                    break;
                }
            }
            if (row == null) {
                row = new ArrayList<>();
                rows.add(row);
            }
            row.add(button);
        }
        for (List<AbstractButton> row : rows) row.sort(Comparator.comparingInt(AbstractButton::getX));
        return rows;
    }

    private static boolean isCrowded(List<AbstractButton> row) {
        for (AbstractButton button : row) {
            if (Minecraft.getInstance().font.width(button.getMessage()) + 20 > button.getWidth()) return true;
        }
        for (int i = 0; i < row.size(); i++) {
            AbstractButton left = row.get(i);
            for (int j = i + 1; j < row.size(); j++) {
                if (row.get(j).getX() < left.getX() + left.getWidth() - 2) return true;
            }
        }
        return false;
    }

    private static AbstractButton find(List<AbstractButton> buttons, List<AbstractButton> excluded,
                                       String... fragments) {
        for (AbstractButton button : buttons) {
            if (excluded.contains(button)) continue;
            String label = button.getMessage().getString().toLowerCase(java.util.Locale.ROOT);
            for (String fragment : fragments) if (label.contains(fragment)) return button;
        }
        return null;
    }

    private static void addIfPresent(List<AbstractButton> buttons, AbstractButton button) {
        if (button != null && !buttons.contains(button)) buttons.add(button);
    }

    private static final class RadialState {
        private final Screen screen;
        private final List<AbstractButton> originals;
        private final List<AbstractButton> mainButtons = new ArrayList<>(6);
        private final List<AbstractButton> extrasButtons = new ArrayList<>(6);
        private final Map<AbstractButton, Boolean> radialActive = new WeakHashMap<>();
        private Button moreOptions;
        private Button centerBack;
        private AbstractButton openToLan;
        private boolean openToLanActive;
        private boolean extrasPage;
        private int guiWidth = -1;
        private int guiHeight = -1;

        private RadialState(Screen screen, List<AbstractButton> originals) {
            this.screen = screen;
            this.originals = List.copyOf(originals);
        }

        private void createActionButtons(AbstractButton backToGame, AbstractButton advancements,
                                         AbstractButton statistics, AbstractButton openToLan,
                                         AbstractButton options, AbstractButton disconnect,
                                         List<AbstractButton> extraSources) {
            this.openToLan = openToLan;
            if (openToLan != null) openToLanActive = openToLan.active;
            mainButtons.add(proxyOrPlaceholder(backToGame, "BACK TO GAME", false));
            mainButtons.add(proxyOrPlaceholder(advancements, "ADVANCEMENTS", false));
            mainButtons.add(proxyOrPlaceholder(statistics, "STATISTICS", false));
            moreOptions = Button.builder(Component.literal("MORE OPTIONS"), button -> showExtras())
                    .bounds(0, 0, 1, 1).build();
            radialActive.put(moreOptions, !extraSources.isEmpty());
            mainButtons.add(moreOptions);
            mainButtons.add(proxyOrPlaceholder(options, "OPTIONS", false));
            mainButtons.add(proxyOrPlaceholder(disconnect, "DISCONNECT", false));

            // These add-on controls are intentionally visible in the custom ring even
            // when the source widget was marked inactive by another menu/layout hook.
            // AbstractWidget rejects mouse clicks before onClick when active is false,
            // while our radial hover renderer still shows the hover state.
            for (AbstractButton button : extraSources) extrasButtons.add(proxy(button, true));
            centerBack = Button.builder(Component.literal(BACK_HITBOX_LABEL), button -> showMain())
                    .bounds(0, 0, 1, 1).build();
            // Proxies must copy the source buttons' active state before the vanilla widgets are disabled.
            for (AbstractButton button : originals) hide(button);
        }

        private AbstractButton proxy(AbstractButton source, boolean forceActive) {
            AbstractButton button = new AbstractButton(0, 0, 1, 1, source.getMessage()) {
                @Override
                public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
                    int slot = PauseRadialMenu.radialSlot(this);
                    if (!active || !visible || event.button() != 0 || slot < 0
                            || !CursorLightRenderer.isPointInRadialSlot(event.x(), event.y(), slot)) {
                        return false;
                    }
                    return PauseRadialMenu.forwardProxyClick(this, event, doubleClick);
                }

                @Override
                public void onPress(InputWithModifiers input) {
                    source.onPress(input);
                }

                @Override
                protected void extractContents(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {}

                @Override
                protected void updateWidgetNarration(NarrationElementOutput narration) {
                    defaultButtonNarrationText(narration);
                }
            };
            boolean proxyActive = source.active || forceActive;
            radialActive.put(button, proxyActive);
            if (forceActive && !source.active) {
                LOGGER.warn("Add-on action '{}' was inactive in the source pause menu; enabled its radial proxy",
                        source.getMessage().getString());
            }
            PROXY_TARGETS.put(button, source);
            return button;
        }

        private AbstractButton proxyOrPlaceholder(AbstractButton source, String label, boolean forceActive) {
            if (source != null) return proxy(source, forceActive);
            Button placeholder = Button.builder(Component.literal(label), button -> {})
                    .bounds(0, 0, 1, 1).build();
            radialActive.put(placeholder, false);
            return placeholder;
        }

        private List<AbstractButton> radialButtons() {
            List<AbstractButton> buttons = new ArrayList<>(mainButtons.size() + extrasButtons.size());
            buttons.addAll(mainButtons);
            buttons.addAll(extrasButtons);
            return buttons;
        }

        private void updateGuiDimensions(int width, int height) {
            if (guiWidth == width && guiHeight == height) return;
            guiWidth = width;
            guiHeight = height;
            if (mainButtons.isEmpty()) return;
            layoutActivePage(extrasPage ? 2 : 1);
        }

        private void activateCurrentPage() {
            if (mainButtons.isEmpty()) return;
            layoutActivePage(extrasPage ? 2 : 1);
        }

        private void showMain() {
            extrasPage = false;
            for (AbstractButton button : radialButtons()) hide(button);
            hide(centerBack);
            layoutActivePage(1);
        }

        private void showExtras() {
            extrasPage = true;
            for (AbstractButton button : radialButtons()) hide(button);
            layoutActivePage(2);
        }

        private void layoutActivePage(int context) {
            setRingContext(context);
            List<AbstractButton> buttons = extrasPage ? extrasButtons : mainButtons;
            for (int i = 0; i < buttons.size(); i++) setRingButton(buttons.get(i), i);
            if (extrasPage) layoutCenterBack();
            layoutOpenToLan();
        }

        private void setRingContext(int context) {
            // Leave a full button row below the wheel when this world exposes Open to LAN.
            CursorLightRenderer.configureRadialMenu(guiWidth, guiHeight, context, openToLan == null ? 0 : 36);
        }

        private void layoutOpenToLan() {
            if (openToLan == null) return;
            int width = Math.min(openToLan.getWidth(), Math.max(80, guiWidth - 32));
            int height = Math.min(openToLan.getHeight(), 24);
            int x = (guiWidth - width) / 2;
            int y = CursorLightRenderer.ringQuadY() + CursorLightRenderer.ringDiameter + 8;
            y = Math.min(y, Math.max(4, guiHeight - height - 4));
            openToLan.setRectangle(x, y, width, height);
            openToLan.active = openToLanActive;
            openToLan.visible = true;
        }

        private void setRingButton(AbstractButton button, int slot) {
            RADIAL_SLOTS.put(button, slot);
            int diameter = CursorLightRenderer.ringDiameter;
            button.setRectangle(CursorLightRenderer.ringQuadX(), CursorLightRenderer.ringQuadY(), diameter, diameter);
            button.active = radialActive.getOrDefault(button, true);
            button.visible = true;
        }

        private void layoutCenterBack() {
            int guiScale = Minecraft.getInstance().getWindow().getGuiScale();
            int headSize = Math.round(58.0f * CursorLightRenderer.menuScaleForGui());
            int minimumHitbox = Math.round(64.0f * 2.0f / Math.max(1, guiScale));
            int hitbox = Math.max(minimumHitbox, Math.min(headSize * 2,
                    Math.round(CursorLightRenderer.ringInnerRadius * 1.3f)));
            centerBack.setRectangle(CursorLightRenderer.ringCenterX - hitbox / 2,
                    CursorLightRenderer.ringCenterY - hitbox / 2, hitbox, hitbox);
            centerBack.active = true;
            centerBack.visible = true;
        }

        private static void hide(AbstractButton button) {
            button.visible = false;
            button.active = false;
        }

        private void clearRadialSlots() {
            for (AbstractButton button : radialButtons()) {
                RADIAL_SLOTS.remove(button);
                PROXY_TARGETS.remove(button);
            }
            if (moreOptions != null) RADIAL_SLOTS.remove(moreOptions);
            if (centerBack != null) RADIAL_SLOTS.remove(centerBack);
        }
    }
}
