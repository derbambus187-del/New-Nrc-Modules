package de.bxmbus.cursorlight;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Util;
import net.minecraft.world.entity.player.PlayerSkin;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

/** Resolves only the local account's skin, shared by the title and pause menus. */
public final class MenuPlayerSkin {
    private static final Logger LOGGER = LoggerFactory.getLogger("CursorLight/MenuPlayerSkin");
    private static final long RETRY_INTERVAL = TimeUnit.SECONDS.toNanos(30);
    // State is read and changed on the render thread; workers only return profile results.
    private static UUID ownerId;
    private static CompletableFuture<GameProfile> initialProfile;
    private static CompletableFuture<GameProfile> retryProfile;
    private static GameProfile recoveredProfile;
    private static List<Property> lookupTextures = List.of();
    private static Supplier<PlayerSkin> accountLookup;
    private static PlayerSkin lastLoadedSkin;
    private static long nextRetryNanos;

    private MenuPlayerSkin() {}

    public static PlayerSkin get() {
        Minecraft minecraft = Minecraft.getInstance();
        UUID currentOwner = minecraft.getUser().getProfileId();
        if (!currentOwner.equals(ownerId)) resetForAccount(minecraft, currentOwner);

        // This is the same skin Minecraft draws on the local player, including
        // skin-provider mods and the richer profile received after joining a server.
        if (minecraft.player != null && currentOwner.equals(minecraft.player.getUUID())) {
            PlayerSkin playerSkin = minecraft.player.getSkin();
            if (!isDefault(playerSkin)) return remember(playerSkin, "local player");
        }

        GameProfile profile = initialProfile.getNow(null);
        if (retryProfile != null && retryProfile.isDone()) {
            GameProfile result = retryProfile.getNow(null);
            retryProfile = null;
            if (result != null && currentOwner.equals(result.id()) && hasTextures(result)) {
                recoveredProfile = result;
            }
        }
        if (recoveredProfile != null) profile = recoveredProfile;

        // A supplier created from an empty startup profile stays empty even when
        // another source later has the textures. Refresh when those properties change.
        if (profile != null && hasTextures(profile)) {
            List<Property> textures = List.copyOf(profile.properties().get("textures"));
            if (accountLookup == null || !lookupTextures.equals(textures)) {
                lookupTextures = textures;
                // Vanilla also passes false for the local player; true can discard
                // a valid local skin and silently replace it with a default skin.
                accountLookup = minecraft.getSkinManager().createLookup(profile, false);
            }
        }
        if (accountLookup != null) {
            PlayerSkin accountSkin = accountLookup.get();
            if (!isDefault(accountSkin)) return remember(accountSkin, "account profile");
        }

        // Keep an already loaded skin while the session service or a download is
        // unavailable. Never let its temporary default overwrite a real skin.
        if (lastLoadedSkin != null) return lastLoadedSkin;
        if (initialProfile.isDone() && retryProfile == null && System.nanoTime() >= nextRetryNanos) {
            retryAccountProfile(minecraft, currentOwner);
        }
        return DefaultPlayerSkin.get(currentOwner);
    }

    private static void resetForAccount(Minecraft minecraft, UUID accountId) {
        ownerId = accountId;
        recoveredProfile = null;
        retryProfile = null;
        accountLookup = null;
        lookupTextures = List.of();
        lastLoadedSkin = null;
        nextRetryNanos = System.nanoTime() + RETRY_INTERVAL;
        // getGameProfile joins Minecraft's network future. Keep that wait off the
        // render thread so a session-server timeout cannot freeze the menu.
        initialProfile = CompletableFuture.supplyAsync(minecraft::getGameProfile, Util.nonCriticalIoPool())
                .exceptionally(error -> {
                    LOGGER.warn("Menu skin profile is not available yet: {}", error.toString());
                    return null;
                });
    }

    private static void retryAccountProfile(Minecraft minecraft, UUID accountId) {
        nextRetryNanos = System.nanoTime() + RETRY_INTERVAL;
        var sessionService = minecraft.services().sessionService();
        retryProfile = CompletableFuture.supplyAsync(() -> {
            try {
                var result = sessionService.fetchProfile(accountId, true);
                return result == null ? null : result.profile();
            } catch (RuntimeException error) {
                LOGGER.warn("Menu skin retry failed; will retry later: {}", error.toString());
                return null;
            }
        }, Util.nonCriticalIoPool());
    }

    private static boolean hasTextures(GameProfile profile) {
        return !profile.properties().get("textures").isEmpty();
    }

    private static boolean isDefault(PlayerSkin skin) {
        if (skin == null) return true;
        Identifier texture = skin.body().texturePath();
        return "minecraft".equals(texture.getNamespace())
                && texture.getPath().startsWith("textures/entity/player/");
    }

    private static PlayerSkin remember(PlayerSkin skin, String source) {
        if (lastLoadedSkin == null || !lastLoadedSkin.body().equals(skin.body())) {
            LOGGER.info("Menu head now uses the skin from {}", source);
        }
        lastLoadedSkin = skin;
        return skin;
    }
}
