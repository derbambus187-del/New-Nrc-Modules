package de.bxmbus.cursorlight;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.gui.components.AbstractWidget;

import java.util.Map;
import java.util.WeakHashMap;

/** Draws the dark dotted background and the light surrounding the cursor. */
public final class CursorLightRenderer {
    public static int buttonColor = 0x665A6A8A;
    public static int glowColor = 0xFFB8D9FF;
    public static int accentColor = 0xFF68D4FF;
    public static int glassOpacityLevel = 3;
    public static boolean cursorLightEnabled = true;
    public static float cursorRadius = 112.0f;
    public static float cursorIntensity = 1.0f;
    public static int gridSpacing = 18;
    public static int dotSize = 2;
    public static float hoverScale = 0.035f;
    public static boolean glassUiActive;
    public static int ringCenterX;
    public static int ringCenterY;
    public static int ringDiameter;
    public static float ringInnerRadius;
    public static float ringOuterRadius;
    public static boolean radialMenuActive;
    /** 0 = title menu, 1 = pause menu, 2 = pause menu's extra-options ring. */
    public static int radialMenuContext;
    public static final double RING_GAP_RADIANS = Math.toRadians(3.0);
    private static final float[] radialHoverProgress = new float[6];
    private static final Map<AbstractWidget, ButtonHoverState> BUTTON_HOVERS = new WeakHashMap<>();
    private static final int MAX_CURSOR_DOTS = 160;
    private static long lastRadialHoverUpdateNanos;
    private static final int BACKGROUND_COLOR = 0xFF050505;

    private CursorLightRenderer() {}

    /** Converts design sizes authored for GUI scale 2 into the current GUI coordinate space. */
    public static float menuScaleForGui() {
        int guiScale = Minecraft.getInstance().getWindow().getGuiScale();
        return CursorLightClient.menuScale * (2.0f / Math.max(1, guiScale));
    }

    /** One geometry source for the title and pause radial menus. All values are GUI units. */
    public static void configureRadialMenu(int width, int height, int context) {
        configureRadialMenu(width, height, context, 0);
    }

    /** Reserve room below the pause ring for an optional standalone action such as Open to LAN. */
    public static void configureRadialMenu(int width, int height, int context, int bottomInset) {
        radialMenuActive = true;
        radialMenuContext = context;
        ringCenterX = width / 2;
        int usableHeight = Math.max(1, height - Math.max(0, bottomInset));
        ringCenterY = usableHeight / 2;
        float maxRadius = Math.max(0.0f, Math.min(
                Math.min(ringCenterX, width - ringCenterX),
                Math.min(ringCenterY, usableHeight - ringCenterY)) - 8.0f);
        float outerRadius = Math.min(140.0f * menuScaleForGui(), maxRadius);
        ringDiameter = Math.max(1, Math.round(outerRadius * 2.0f));
        ringInnerRadius = outerRadius * 0.54f;
        ringOuterRadius = outerRadius * 0.98f;
    }

    public static int ringQuadX() {
        return ringCenterX - ringDiameter / 2;
    }

    public static int ringQuadY() {
        return ringCenterY - ringDiameter / 2;
    }

    public static int radialLabelX(int slot) {
        double angle = -Math.PI / 2.0 + slot * Math.PI / 3.0;
        return ringCenterX + (int) Math.round(Math.cos(angle) * radialLabelRadius());
    }

    public static int radialLabelY(int slot) {
        double angle = -Math.PI / 2.0 + slot * Math.PI / 3.0;
        return ringCenterY + (int) Math.round(Math.sin(angle) * radialLabelRadius()) - 4;
    }

    public static int radialLabelWidth() {
        return Math.max(1, (int) Math.floor(radialLabelRadius()
                * (Math.PI / 3.0 - RING_GAP_RADIANS)));
    }

    private static float radialLabelRadius() {
        return (ringInnerRadius + ringOuterRadius) * 0.5f;
    }

    public static int radialMenuSlot(String rawLabel) {
        String label = rawLabel.toLowerCase(java.util.Locale.ROOT);
        if (label.contains("mods")) return 0;
        if (label.contains("single") || label.contains("einzel")) return 1;
        if (label.contains("multiplayer") || label.contains("mehrspieler")) return 2;
        if (label.contains("realms") || label.contains("realm")) return 3;
        if (label.contains("options") || label.contains("optionen")) return 4;
        if (label.contains("quit") || label.contains("beenden")) return 5;
        return -1;
    }

    public static int radialMenuSlot(AbstractWidget widget) {
        if (!radialMenuActive) return -1;
        if (radialMenuContext == 0) return radialMenuSlot(widget.getMessage().getString());
        return widget instanceof AbstractButton button ? PauseRadialMenu.radialSlot(button) : -1;
    }

    public static boolean isPointInRadialSlot(double mouseX, double mouseY, int slot) {
        if (!radialMenuActive || slot < 0 || slot > 5) return false;
        double dx = mouseX - ringCenterX;
        double dy = mouseY - ringCenterY;
        double radius = Math.hypot(dx, dy);
        double angle = Math.atan2(dy, dx);
        double centerAngle = -Math.PI / 2.0 + slot * Math.PI / 3.0;
        double angleDelta = Math.atan2(Math.sin(angle - centerAngle), Math.cos(angle - centerAngle));
        double halfSector = Math.PI / 6.0 - RING_GAP_RADIANS / 2.0;
        if (radius < ringInnerRadius || radius > ringOuterRadius || Math.abs(angleDelta) > halfSector) return false;
        // Match the shader's rounded-sector SDF boundary exactly. Keeping the hit test
        // on this same annular wedge prevents hover/click from appearing detached.
        return Math.abs(angleDelta) <= halfSector;
    }

    public static void resetRadialHoverAnimation() {
        java.util.Arrays.fill(radialHoverProgress, 0.0f);
        lastRadialHoverUpdateNanos = System.nanoTime();
    }

    public static float updateRadialHoverProgress(int activeSlot, double mouseX, double mouseY) {
        long now = System.nanoTime();
        if (lastRadialHoverUpdateNanos == 0L) lastRadialHoverUpdateNanos = now;
        float elapsed = Math.min(0.05f, (now - lastRadialHoverUpdateNanos) / 1_000_000_000.0f);
        lastRadialHoverUpdateNanos = now;
        float step = elapsed / 0.16f;
        for (int slot = 0; slot < radialHoverProgress.length; slot++) {
            float target = isPointInRadialSlot(mouseX, mouseY, slot) ? 1.0f : 0.0f;
            if (target > radialHoverProgress[slot]) {
                radialHoverProgress[slot] = Math.min(target, radialHoverProgress[slot] + step);
            } else {
                radialHoverProgress[slot] = Math.max(target, radialHoverProgress[slot] - step);
            }
        }
        float progress = radialHoverProgress[activeSlot];
        return progress * progress * (3.0f - 2.0f * progress);
    }

    /** Smoothly animates button hover without mixing it into the SDF shape/slot bits. */
    public static float updateButtonHover(AbstractWidget button, boolean hovered) {
        long now = System.nanoTime();
        ButtonHoverState state = BUTTON_HOVERS.computeIfAbsent(button, ignored -> new ButtonHoverState(now));
        float elapsed = Math.min(0.05f, (now - state.lastUpdateNanos) / 1_000_000_000.0f);
        state.lastUpdateNanos = now;
        float target = hovered ? 1.0f : 0.0f;
        float easing = 1.0f - (float) Math.exp(-elapsed / 0.14f);
        state.progress += (target - state.progress) * easing;
        if (Math.abs(target - state.progress) < 0.003f) state.progress = target;
        return state.progress;
    }

    private static final class ButtonHoverState {
        private float progress;
        private long lastUpdateNanos;

        private ButtonHoverState(long now) {
            lastUpdateNanos = now;
        }
    }

    public static void render(GuiGraphicsExtractor graphics, int mouseX, int mouseY) {
        int screenWidth = graphics.guiWidth();
        int screenHeight = graphics.guiHeight();
        graphics.fill(0, 0, screenWidth, screenHeight, BACKGROUND_COLOR);
        if (!cursorLightEnabled) return;

        int radius = Math.max(32, Math.round(cursorRadius));
        int spacing = renderSpacing(radius);
        int firstX = Math.max(0, (mouseX / spacing - 7) * spacing);
        int lastX = Math.min(screenWidth, mouseX + radius + spacing);
        int firstY = Math.max(0, (mouseY / spacing - 7) * spacing);
        int lastY = Math.min(screenHeight, mouseY + radius + spacing);

        for (int x = firstX; x <= lastX; x += spacing) {
            for (int y = firstY; y <= lastY; y += spacing) {
                drawDotNearCursor(graphics, x, y, mouseX, mouseY);
            }
        }
    }

    public static void renderDotsBetween(GuiGraphicsExtractor graphics, int mouseX, int mouseY,
                                         int minY, int maxY) {
        if (!cursorLightEnabled) return;
        int screenWidth = graphics.guiWidth();
        int screenHeight = graphics.guiHeight();
        int radius = Math.max(32, Math.round(cursorRadius));
        int spacing = renderSpacing(radius);
        int firstX = Math.max(0, (mouseX / spacing - 7) * spacing);
        int lastX = Math.min(screenWidth, mouseX + radius + spacing);
        int firstY = Math.max(minY, Math.max(0, (mouseY / spacing - 7) * spacing));
        int lastY = Math.min(maxY, Math.min(screenHeight, mouseY + radius + spacing));
        for (int x = firstX; x <= lastX; x += spacing) {
            for (int y = firstY; y <= lastY; y += spacing) {
                drawDotNearCursor(graphics, x, y, mouseX, mouseY);
            }
        }
    }

    private static void drawDotNearCursor(GuiGraphicsExtractor graphics, int x, int y,
                                          int mouseX, int mouseY) {
        float offsetX = x - mouseX;
        float offsetY = y - mouseY;
        float distance = (float) Math.sqrt(offsetX * offsetX + offsetY * offsetY);
        if (distance >= cursorRadius) {
            return;
        }

        float lightStrength = (1.0f - distance / cursorRadius) * cursorIntensity;
        int red = (glowColor >> 16) & 255;
        int green = (glowColor >> 8) & 255;
        int blue = glowColor & 255;
        red = clampChannel(12 + (int) ((red - 12) * lightStrength));
        green = clampChannel(12 + (int) ((green - 12) * lightStrength));
        blue = clampChannel(12 + (int) ((blue - 12) * lightStrength));
        int alpha = Math.min(255, 60 + (int) (lightStrength * 195));
        int color = (alpha << 24) | (red << 16) | (green << 8) | blue;
        int size = Math.max(1, dotSize);
        graphics.fill(x, y, x + size, y + size, color);
    }

    private static int clampChannel(int value) {
        return Math.max(0, Math.min(255, value));
    }

    /** Keeps high-radius, high-density settings from flooding the GUI render queue. */
    private static int renderSpacing(int radius) {
        int spacing = Math.max(8, gridSpacing);
        double estimatedDots = Math.PI * radius * radius / (spacing * spacing);
        if (estimatedDots > MAX_CURSOR_DOTS) {
            spacing = Math.max(spacing, (int) Math.ceil(Math.sqrt(
                    Math.PI * radius * radius / MAX_CURSOR_DOTS)));
        }
        return spacing;
    }
}
