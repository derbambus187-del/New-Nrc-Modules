package de.bxmbus.cursorlight;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.TabButton;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.resources.Identifier;

import java.util.ArrayDeque;
import java.util.Deque;

/** Styles standard control backgrounds while their native contents and input stay intact. */
public final class GlassWidgets {
    private static final Deque<AbstractWidget> CONTEXT = new ArrayDeque<>();

    private GlassWidgets() {}

    public static boolean enabled() {
        return Minecraft.getInstance().gui.screen() instanceof TitleScreen
                ? CursorLightClient.glassForTitle() : CursorLightClient.glassForOtherMenus();
    }

    public static void beginWidget(AbstractWidget widget) { CONTEXT.push(widget); }
    public static void endWidget() { if (!CONTEXT.isEmpty()) CONTEXT.pop(); }
    public static void resetFrame() { CONTEXT.clear(); }

    public static boolean replaceSprite(GuiGraphicsExtractor g, Identifier sprite,
                                        int x, int y, int width, int height, int spriteColor) {
        if (!enabled() || width <= 0 || height <= 0 || !"minecraft".equals(sprite.getNamespace())) return false;
        String path = sprite.getPath();
        boolean checkbox = path.startsWith("widget/checkbox");
        boolean slider = path.startsWith("widget/slider");
        boolean tab = path.startsWith("widget/tab");
        boolean input = path.startsWith("widget/text_field");
        boolean scrollbar = path.startsWith("widget/scroller");
        if (!checkbox && !slider && !tab && !input && !scrollbar && !path.startsWith("widget/button")) return false;

        AbstractWidget widget = CONTEXT.peek();
        if ((spriteColor >>> 24) == 0 || (widget != null && widget.getAlpha() <= 0.0f)) return true;
        boolean disabled = path.contains("disabled") || (widget != null && !widget.active);
        boolean hovered = path.contains("highlighted") || (widget != null && widget.isHoveredOrFocused());
        float hover = widget == null ? (hovered ? 1.0f : 0.0f)
                : CursorLightRenderer.updateButtonHover(widget, hovered && !disabled);
        hover *= CursorLightRenderer.hoverScale <= 0.0f ? 0.0f : 0.72f;
        boolean selected = path.contains("selected") || (widget instanceof TabButton tabButton && tabButton.isSelected());
        if (selected) hover = Math.max(hover, 0.28f);
        boolean handle = path.contains("handle") || (scrollbar && !path.contains("background"));
        int rgb = handle ? CursorLightRenderer.accentColor : CursorLightRenderer.buttonColor;
        int color = (disabled ? 0x80000000 : 0) | (rgb & 0xFFFFFF);
        int shape = input || tab || checkbox ? 6 : -1;
        if (!LiquidGlassButtonRenderer.submit(g, x, y, width, height, color, shape, hover, true)) return false;
        if (checkbox && selected) drawCheck(g, x, y, width, height, disabled ? 0xFF8D98AA : 0xFFF4FBFF);
        return true;
    }

    public static boolean panel(GuiGraphicsExtractor g, int x, int y, int width, int height) {
        return enabled() && LiquidGlassButtonRenderer.submit(g, x, y, width, height,
                CursorLightRenderer.buttonColor & 0xFFFFFF, 6, 0.0f, true);
    }

    private static void drawCheck(GuiGraphicsExtractor g, int x, int y, int width, int height, int color) {
        line(g, x + width * 0.24f, y + height * 0.51f,
                x + width * 0.43f, y + height * 0.70f, color);
        line(g, x + width * 0.43f, y + height * 0.70f,
                x + width * 0.77f, y + height * 0.30f, color);
    }

    private static void line(GuiGraphicsExtractor g, float x0, float y0, float x1, float y1, int color) {
        g.pose().pushMatrix();
        g.pose().translate(x0, y0);
        g.pose().rotate((float) Math.atan2(y1 - y0, x1 - x0));
        g.fill(0, -1, Math.max(1, (int) Math.ceil(Math.hypot(x1 - x0, y1 - y0))), 1, color);
        g.pose().popMatrix();
    }
}
