package de.bxmbus.cursorlight;

import com.mojang.blaze3d.GpuFormat;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Copies the completed, unblurred screen background before the glass-button stratum is rendered. */
public final class GlassBackdrop {
    private static final Logger LOGGER = LoggerFactory.getLogger("CursorLight/LiquidGlass");
    private static GpuTexture texture;
    private static GpuTextureView view;
    private static boolean requested;
    private static boolean boundaryMarked;
    private static boolean loggedCapture;
    private static boolean loggedBoundaryWarning;

    private GlassBackdrop() {}

    public static void resetFrame() {
        requested = false;
        boundaryMarked = false;
    }

    public static GpuTextureView acquire(boolean captureBackground) {
        RenderTarget main = Minecraft.getInstance().gameRenderer.mainRenderTarget();
        int width = main.width;
        int height = main.height;
        if (width <= 0 || height <= 0) return null;

        if (texture == null || texture.getWidth(0) != width || texture.getHeight(0) != height) {
            close();
            var device = RenderSystem.getDevice();
            texture = device.createTexture("cursorlight_liquid_glass_backdrop",
                    GpuTexture.USAGE_COPY_DST | GpuTexture.USAGE_TEXTURE_BINDING,
                    GpuFormat.RGBA8_UNORM, width, height, 1, 1);
            view = device.createTextureView(texture);
        }
        if (captureBackground) requested = true;
        return view;
    }

    public static boolean capturePending() {
        return requested;
    }

    /** Starts a new GUI stratum so the current screen background is drawn before its buttons. */
    public static void markAfterScreenBackground(GuiGraphicsExtractor graphics) {
        if (CursorLightClient.liquidGlassMode == 0 || boundaryMarked) return;
        boundaryMarked = true;
        try {
            // Start a fresh button stratum, then mark it as the first stratum after the
            // background capture point. GameRendererMixin cancels the actual blur.
            graphics.guiRenderState.nextStratum();
            graphics.guiRenderState.blurBeforeThisStratum();
        } catch (IllegalStateException alreadyMarked) {
            if (!loggedBoundaryWarning) {
                loggedBoundaryWarning = true;
                LOGGER.warn("Another GUI blur boundary already exists; using that background capture point");
            }
        }
    }

    /** Called after Minecraft draws its background stratum and before it draws the button stratum. */
    public static void capture() {
        if (!requested || texture == null) return;
        requested = false;

        RenderTarget main = Minecraft.getInstance().gameRenderer.mainRenderTarget();
        if (main.width != texture.getWidth(0) || main.height != texture.getHeight(0)) return;

        try {
            RenderSystem.getDevice().createCommandEncoder().copyTextureToTexture(
                    main.getColorTexture(), texture, 0, 0, 0, 0, 0, main.width, main.height);
            if (!loggedCapture) {
                loggedCapture = true;
                LOGGER.info("Liquid-glass screen background captured before menu buttons ({}x{})", main.width, main.height);
            }
        } catch (RuntimeException exception) {
            LOGGER.error("Liquid-glass backdrop capture failed", exception);
        }
    }

    private static void close() {
        if (view != null) view.close();
        if (texture != null) texture.close();
        view = null;
        texture = null;
    }
}
