package de.bxmbus.cursorlight;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import java.util.Locale;

/** Multi-page design studio for Cursor Light colors, glass, and cursor layout. */
public final class CursorLightConfigScreen extends Screen {
    private static final float[] SCALES={.70f,.85f,1f,1.15f,1.30f,1.45f};
    private static final float[] HOVERS={0f,.015f,.025f,.035f,.05f,.07f,.09f,.12f};
    private static final float[] RADII={56,72,88,104,120,144,168,192,220};
    private static final float[] INTENSITIES={.25f,.4f,.55f,.7f,.85f,1f,1.15f,1.3f,1.5f};
    private static final int[] SPACINGS={16,18,20,22,26,30,36};
    private static final int[] DOTS={1,2,3,4,5,6};
    private static final int[] OPACITY={0,1,2,3,4,5,6,7};
    private static final Identifier SPECTRUM=Identifier.fromNamespaceAndPath("cursorlight","textures/gui/color-spectrum.png");
    private static final Identifier BRIGHTNESS=Identifier.fromNamespaceAndPath("cursorlight","textures/gui/brightness-gradient.png");
    private static final Theme[] THEMES={
        new Theme("ARCTIC",0x665D7899,0xFF8BE4FF,0xFF68D4FF),
        new Theme("VIOLET",0x666A587F,0xFFD2A2FF,0xFFB58AFF),
        new Theme("MINT",0x66526F6A,0xFF78F0C1,0xFF69E0BA),
        new Theme("EMBER",0x667A594C,0xFFFFB374,0xFFFFA15C),
        new Theme("ROSE",0x66745168,0xFFFF9BBB,0xFFFF83B5),
        new Theme("SLATE",0x665C6575,0xFFB7C8E1,0xFF91A9CC)
    };
    private final Screen parent;
    private Page page=Page.OVERVIEW;
    private ColorTarget colorTarget=ColorTarget.BUTTONS;
    private float hue,saturation=.55f,brightness=1f;
    private int left,top,panelW,panelH,sidebarW,contentX,contentY,contentW,contentH;
    private int spectrumX,spectrumY,spectrumW,spectrumH,brightnessY,previewX,previewW,dragMode;

    public CursorLightConfigScreen(Screen parent){super(Component.literal("Cursor Light | Design Studio"));this.parent=parent;loadColor();}

    @Override protected void init(){
        panelW=Math.max(0,Math.min(860,width-28)); panelH=Math.max(0,Math.min(520,height-20));
        left=(width-panelW)/2; top=(height-panelH)/2; sidebarW=Math.min(176,Math.max(132,panelW/4));
        contentX=left+sidebarW+26; contentY=top+72; contentW=Math.max(0,left+panelW-24-contentX);
        contentH=Math.max(0,top+panelH-50-contentY); if(page==Page.COLORS) setPickerGeometry(); buildWidgets();
    }

    private void buildWidgets(){
        clearWidgets();
        int y=top+78, navW=Math.max(94,sidebarW-24);
        for(Page item:Page.values()){
            addRenderableWidget(Button.builder(Component.literal(item.label),b->{page=item;init();})
                    .bounds(left+12,y,navW,29).build()); y+=36;
        }
        switch(page){case OVERVIEW->overviewWidgets();case COLORS->colorWidgets();case GLASS->glassWidgets();case CURSOR->cursorWidgets();case LAYOUT->layoutWidgets();}
        addRenderableWidget(Button.builder(Component.literal("CLOSE"),b->minecraft.setScreenAndShow(parent))
                .bounds(left+panelW-112,top+panelH-36,88,24).build());
    }

    private void overviewWidgets(){
        int half=(contentW-10)/2;
        addRenderableWidget(Button.builder(Component.literal("BUTTON STYLE  ·  "+modeName()),b->{CursorLightClient.liquidGlassMode=(CursorLightClient.liquidGlassMode+1)%3;saveRefresh();})
                .bounds(contentX,contentY+126,half,30).build());
        addRenderableWidget(Button.builder(Component.literal(scaleLabel()),b->{CursorLightClient.menuScale=next(CursorLightClient.menuScale,SCALES,1);saveRefresh();})
                .bounds(contentX+half+10,contentY+126,half,30).build());
        int gap=6,w=Math.max(70,(contentW-gap*2)/3),y=contentY+190;
        for(int i=0;i<THEMES.length;i++){Theme t=THEMES[i];int row=i/3,col=i%3;
            addRenderableWidget(Button.builder(Component.literal(t.name),b->applyTheme(t))
                    .bounds(contentX+col*(w+gap),y+row*28,w,24).build());}
        int actionY=contentY+251;
        int openWidth=Math.min(contentW,240),resetWidth=Math.min(contentW,142);
        addRenderableWidget(Button.builder(Component.literal("OPEN COLOR STUDIO  →"),b->{page=Page.COLORS;init();})
                .bounds(contentX,actionY,openWidth,27).build());
        addRenderableWidget(Button.builder(Component.literal("RESET ALL"),b->resetAll())
                .bounds(contentW>=openWidth+resetWidth+8?contentX+contentW-resetWidth:contentX,
                        contentW>=openWidth+resetWidth+8?actionY:actionY+30,resetWidth,27).build());
    }

    private void colorWidgets(){
        int gap=6,w=Math.max(60,(contentW-gap*2)/3),y=contentY+25;
        for(int i=0;i<ColorTarget.values().length;i++){ColorTarget target=ColorTarget.values()[i];
            addRenderableWidget(Button.builder(Component.literal(target.label),b->{colorTarget=target;loadColor();init();})
                    .bounds(contentX+i*(w+gap),y,w,26).build());}
        int py=top+panelH-88,presetW=Math.max(60,(contentW-gap*2)/3);
        for(int i=0;i<THEMES.length;i++){Theme t=THEMES[i];int row=i/3,col=i%3;
            addRenderableWidget(Button.builder(Component.literal(t.name),b->applyTheme(t))
                    .bounds(contentX+col*(presetW+gap),py+row*25,presetW,22).build());}
    }

    private void glassWidgets(){
        addRenderableWidget(Button.builder(Component.literal("BUTTON STYLE  ·  "+modeName()),b->{CursorLightClient.liquidGlassMode=(CursorLightClient.liquidGlassMode+1)%3;saveRefresh();})
                .bounds(contentX+8,contentY+38,contentW-16,32).build());
        addRenderableWidget(Button.builder(Component.literal("GLASS FINISH  ·  "+finishName()),b->{CursorLightClient.glassPreset=(CursorLightClient.glassPreset+1)%4;saveRefresh();})
                .bounds(contentX+8,contentY+83,contentW-16,32).build());
        choiceRow(contentY+132,"GLASS DENSITY",(56+CursorLightRenderer.glassOpacityLevel*4)+"%",d->{CursorLightRenderer.glassOpacityLevel=next(CursorLightRenderer.glassOpacityLevel,OPACITY,d);saveRefresh();});
        choiceRow(contentY+174,"HOVER RESPONSE",percent(CursorLightRenderer.hoverScale),d->{CursorLightRenderer.hoverScale=next(CursorLightRenderer.hoverScale,HOVERS,d);saveRefresh();});
        addRenderableWidget(Button.builder(Component.literal("RESET GLASS SETTINGS"),b->{CursorLightClient.liquidGlassMode=2;CursorLightClient.glassPreset=1;CursorLightRenderer.hoverScale=.035f;saveRefresh();})
                .bounds(contentX+8,contentY+220,Math.min(contentW-16,220),27).build());
    }

    private void cursorWidgets(){
        choiceRow(contentY+124,"LIGHT RADIUS",Math.round(CursorLightRenderer.cursorRadius)+" px",d->{CursorLightRenderer.cursorRadius=next(CursorLightRenderer.cursorRadius,RADII,d);saveRefresh();});
        choiceRow(contentY+168,"LIGHT INTENSITY",percent(CursorLightRenderer.cursorIntensity),d->{CursorLightRenderer.cursorIntensity=next(CursorLightRenderer.cursorIntensity,INTENSITIES,d);saveRefresh();});
        addRenderableWidget(Button.builder(Component.literal("EDIT CURSOR COLOR  →"),b->{colorTarget=ColorTarget.CURSOR;loadColor();page=Page.COLORS;init();})
                .bounds(contentX+8,contentY+214,Math.min(contentW-16,250),28).build());
        addRenderableWidget(Button.builder(Component.literal(CursorLightRenderer.cursorLightEnabled?"CURSOR LIGHT  ·  ON":"CURSOR LIGHT  ·  OFF"),b->{CursorLightRenderer.cursorLightEnabled=!CursorLightRenderer.cursorLightEnabled;saveRefresh();})
                .bounds(contentX+8,contentY+250,Math.min(contentW-16,250),27).build());
        addRenderableWidget(Button.builder(Component.literal("RESET CURSOR"),b->{CursorLightRenderer.cursorRadius=112;CursorLightRenderer.cursorIntensity=1;CursorLightRenderer.glowColor=0xFFB8D9FF;saveRefresh();})
                .bounds(contentX+8,contentY+286,Math.min(contentW-16,190),27).build());
    }

    private void layoutWidgets(){
        choiceRow(contentY+22,"MENU SCALE",scaleLabel(),d->{CursorLightClient.menuScale=next(CursorLightClient.menuScale,SCALES,d);saveRefresh();});
        choiceRow(contentY+70,"DOT SPACING",CursorLightRenderer.gridSpacing+" px",d->{CursorLightRenderer.gridSpacing=next(CursorLightRenderer.gridSpacing,SPACINGS,d);saveRefresh();});
        choiceRow(contentY+118,"DOT SIZE",CursorLightRenderer.dotSize+" px",d->{CursorLightRenderer.dotSize=next(CursorLightRenderer.dotSize,DOTS,d);saveRefresh();});
        addRenderableWidget(Button.builder(Component.literal("RESET LAYOUT"),b->{CursorLightClient.menuScale=1;CursorLightRenderer.gridSpacing=18;CursorLightRenderer.dotSize=2;saveRefresh();})
                .bounds(contentX+8,contentY+175,Math.min(contentW-16,190),27).build());
    }

    private void choiceRow(int y,String label,String value,java.util.function.IntConsumer adjust){
        int size=30,l=contentX+8,r=contentX+contentW-8;
        addRenderableWidget(Button.builder(Component.literal("−"),b->adjust.accept(-1)).bounds(l,y,size,27).build());
        addRenderableWidget(Button.builder(Component.literal("+"),b->adjust.accept(1)).bounds(r-size,y,size,27).build());
        addRenderableWidget(Button.builder(Component.literal(label+"  ·  "+value),b->{}).bounds(l+size+8,y,Math.max(64,r-l-size*2-16),27).build());
    }

    private void applyTheme(Theme t){CursorLightRenderer.buttonColor=t.button;CursorLightRenderer.glowColor=t.cursor;CursorLightRenderer.accentColor=t.accent;saveRefresh();}
    private void resetAll(){CursorLightRenderer.buttonColor=0x665A6A8A;CursorLightRenderer.glowColor=0xFFB8D9FF;CursorLightRenderer.accentColor=0xFF68D4FF;CursorLightRenderer.glassOpacityLevel=3;CursorLightRenderer.cursorLightEnabled=true;CursorLightRenderer.cursorRadius=112;CursorLightRenderer.cursorIntensity=1;CursorLightRenderer.gridSpacing=18;CursorLightRenderer.dotSize=2;CursorLightRenderer.hoverScale=.035f;CursorLightClient.menuScale=1;CursorLightClient.liquidGlassMode=2;CursorLightClient.glassPreset=1;saveRefresh();}
    private void saveRefresh(){CursorLightClient.saveConfig();init();}
    private String modeName(){return switch(CursorLightClient.liquidGlassMode){case 0->"OFF";case 1->"TITLE ONLY";default->"EVERYWHERE";};}
    private String finishName(){return switch(CursorLightClient.glassPreset){case 0->"SUBTLE";case 1->"BALANCED";case 2->"BOLD";default->"PRISMATIC";};}
    private String scaleLabel(){return String.format(Locale.ROOT,"MENU SCALE  ·  %.0f%%",CursorLightClient.menuScale*100);}
    private void setPickerGeometry(){
        previewW=Math.min(126,Math.max(90,contentW/4));spectrumX=contentX+2;spectrumY=contentY+69;
        spectrumW=Math.max(64,contentW-previewW-20);spectrumH=Math.max(62,Math.min(126,contentH-157));
        previewX=spectrumX+spectrumW+14;brightnessY=spectrumY+spectrumH+10;
    }
    private void loadColor(){
        int color=switch(colorTarget){case BUTTONS->CursorLightRenderer.buttonColor;case CURSOR->CursorLightRenderer.glowColor;case ACCENT->CursorLightRenderer.accentColor;};
        float[] hsv=java.awt.Color.RGBtoHSB((color>>>16)&255,(color>>>8)&255,color&255,null);hue=hsv[0];saturation=hsv[1];brightness=hsv[2];
    }
    private void updateSpectrum(double x,double y){hue=clamp((float)((x-spectrumX)/Math.max(1,spectrumW-1)));saturation=1-clamp((float)((y-spectrumY)/Math.max(1,spectrumH-1)));applyColor();}
    private void updateBrightness(double x){brightness=clamp((float)((x-spectrumX)/Math.max(1,spectrumW-1)));applyColor();}
    private void applyColor(){
        int rgb=java.awt.Color.HSBtoRGB(hue,saturation,brightness)&0xFFFFFF;
        switch(colorTarget){case BUTTONS->CursorLightRenderer.buttonColor=0x66000000|rgb;case CURSOR->CursorLightRenderer.glowColor=0xFF000000|rgb;case ACCENT->CursorLightRenderer.accentColor=0xFF000000|rgb;}
    }
    private int selectedRgb(){return java.awt.Color.HSBtoRGB(hue,saturation,brightness)&0xFFFFFF;}

    @Override public boolean mouseClicked(MouseButtonEvent event,boolean doubleClick){
        if(page==Page.COLORS&&event.button()==0&&contains(spectrumX,spectrumY,spectrumW,spectrumH,event.x(),event.y())){dragMode=1;updateSpectrum(event.x(),event.y());CursorLightClient.saveConfig();return true;}
        if(page==Page.COLORS&&event.button()==0&&contains(spectrumX,brightnessY-3,spectrumW,18,event.x(),event.y())){dragMode=2;updateBrightness(event.x());CursorLightClient.saveConfig();return true;}
        return super.mouseClicked(event,doubleClick);
    }
    @Override public boolean mouseDragged(MouseButtonEvent event,double dx,double dy){
        if(dragMode==1){updateSpectrum(event.x(),event.y());return true;}if(dragMode==2){updateBrightness(event.x());return true;}return super.mouseDragged(event,dx,dy);
    }
    @Override public boolean mouseReleased(MouseButtonEvent event){if(dragMode!=0){dragMode=0;CursorLightClient.saveConfig();return true;}return super.mouseReleased(event);}

    @Override public void extractBackground(GuiGraphicsExtractor g,int mouseX,int mouseY,float delta){
        CursorLightRenderer.radialMenuActive=false;CursorLightRenderer.glassUiActive=CursorLightClient.glassForOtherMenus();CursorLightRenderer.render(g,mouseX,mouseY);
        roundedGradient(g,left+4,top+8,panelW,panelH,22,0x66000000,0x88000000);
        roundedGradient(g,left-2,top-2,panelW+4,panelH+4,22,CursorLightRenderer.accentColor,0xAA735EFF);
        roundedGradient(g,left,top,panelW,panelH,20,0xF51A2A42,0xF20A101C);
        roundedGradient(g,left+1,top+1,sidebarW,panelH-2,18,0xCC101B2B,0xCC0C1421);
        roundedFill(g,left+sidebarW,top+16,1,panelH-32,1,0x557BB9E8);
        roundedFill(g,left+14,top+11,56,2,1,CursorLightRenderer.accentColor);
        roundedFill(g,left+16,top+52,panelW-32,1,1,0x557BB9E8);
        g.text(font,"CURSORLIGHT",left+16,top+20,0xFFF3F8FF);g.text(font,"DESIGN STUDIO",left+16,top+37,CursorLightRenderer.accentColor);
        g.text(font,"PERSONALIZE YOUR MENU",contentX,top+19,0xFFF0F5FC);g.text(font,"Changes save automatically",contentX,top+35,0xFF8FA5C0);
        g.text(font,"LIVE",left+panelW-58,top+22,CursorLightRenderer.accentColor);
        int activeY=top+78+page.ordinal()*36;roundedGradient(g,left+8,activeY-2,sidebarW-16,31,8,0x664A6B8F,0x55334460);
        roundedFill(g,left+8,activeY+3,2,21,1,CursorLightRenderer.accentColor);
        switch(page){case OVERVIEW->drawOverview(g);case COLORS->drawColors(g);case GLASS->drawGlass(g);case CURSOR->drawCursor(g);case LAYOUT->drawLayout(g);}
        g.text(font,"AUTO-SAVED  ·  CURSOR LIGHT",left+18,top+panelH-31,0xFF71839B);
        if(CursorLightClient.glassForOtherMenus())GlassBackdrop.markAfterScreenBackground(g);
    }

    private void drawOverview(GuiGraphicsExtractor g){
        g.text(font,"YOUR CURRENT LOOK",contentX,contentY,0xFFD7E4F5);int y=contentY+22;
        roundedGradient(g,contentX,y,contentW,92,14,0xAA30445E,0x66303A53);
        roundedFill(g,contentX+13,y+11,contentW-26,1,1,0x66FFFFFF);
        g.text(font,"BUTTON GLASS",contentX+16,y+18,0xFFB7C8DF);g.text(font,modeName()+"  ·  "+finishName(),contentX+16,y+36,0xFFF4F7FC);
        int sw=y+61;roundedFill(g,contentX+16,sw,88,12,5,CursorLightRenderer.buttonColor);g.text(font,"BUTTON",contentX+112,sw+2,0xFFCCD8E8);
        int cx=contentX+Math.max(210,contentW/2);roundedFill(g,cx,sw-1,14,14,7,CursorLightRenderer.glowColor);g.text(font,"CURSOR LIGHT",cx+20,sw+2,0xFFCCD8E8);
        g.text(font,"QUICK THEMES  ·  click to apply",contentX,contentY+172,0xFFD7E4F5);
    }

    private void drawColors(GuiGraphicsExtractor g){
        roundedGradient(g,spectrumX-5,spectrumY-23,contentW+10,spectrumH+63,14,0x772B405C,0x55303A53);
        g.text(font,"PICK A COLOR",spectrumX,spectrumY-14,0xFFD6E5F8);
        roundedFill(g,spectrumX-2,spectrumY-2,spectrumW+4,spectrumH+4,8,0xFFA8C7E9);
        g.blit(RenderPipelines.GUI_TEXTURED,SPECTRUM,spectrumX,spectrumY,0,0,spectrumW,spectrumH,512,192,512,192,0xFFFFFFFF);
        int mx=spectrumX+Math.round(hue*(spectrumW-1)),my=spectrumY+Math.round((1-saturation)*(spectrumH-1));
        g.fill(mx-7,my-7,mx+8,my+8,0xFF111927);g.fill(mx-4,my-4,mx+5,my+5,0xFFFFFFFF);
        g.text(font,"BRIGHTNESS",spectrumX,brightnessY-12,0xFFAFBED3);roundedFill(g,spectrumX-2,brightnessY-2,spectrumW+4,14,6,0xFFA8C7E9);
        int hc=java.awt.Color.HSBtoRGB(hue,saturation,1f)&0xFFFFFF;
        g.blit(RenderPipelines.GUI_TEXTURED,BRIGHTNESS,spectrumX,brightnessY,0,0,spectrumW,10,512,8,512,8,0xFF000000|hc);
        int bx=spectrumX+Math.round(brightness*(spectrumW-1));g.fill(bx-2,brightnessY-3,bx+3,brightnessY+13,0xFF101622);g.fill(bx-1,brightnessY-2,bx+2,brightnessY+12,0xFFFFFFFF);
        roundedGradient(g,previewX,spectrumY-2,previewW,spectrumH+28,12,0xAA263853,0x88303A50);
        g.text(font,colorTarget.label,previewX+8,spectrumY+7,0xFFD6E2F3);
        int size=Math.min(previewW-20,Math.max(40,spectrumH/2)),sx=previewX+(previewW-size)/2,sy=spectrumY+27;
        roundedFill(g,sx-3,sy-3,size+6,size+6,10,CursorLightRenderer.accentColor);roundedFill(g,sx,sy,size,size,8,0xFF000000|selectedRgb());
        g.centeredText(font,String.format(Locale.ROOT,"#%06X",selectedRgb()),previewX+previewW/2,spectrumY+spectrumH+13,0xFFF2F7FF);
        g.text(font,"DRAG TO PICK  ·  AUTO-SAVED",spectrumX,brightnessY+17,0xFF8FA6C3);
    }

    private void drawGlass(GuiGraphicsExtractor g){
        g.text(font,"LIQUID GLASS",contentX,contentY,0xFFD7E4F5);
        g.text(font,"Theme for controls, menu panels and the Tab player list.",contentX,contentY+21,0xFF91A5BF);
        g.text(font,"TUNE TRANSPARENCY AND HOVER RESPONSE",contentX+8,contentY+119,0xFF9AAFC9);
        g.text(font,"Hover brightens the glass and rim while keeping button positions stable.",contentX+8,contentY+208,0xFF91A5BF);
    }
    private void drawCursor(GuiGraphicsExtractor g){
        g.text(font,"CURSOR LIGHT",contentX,contentY,0xFFD7E4F5);
        roundedGradient(g,contentX,contentY+22,contentW,94,14,0xAA263C58,0x55303A53);
        int cx=contentX+45,cy=contentY+69,dot=Math.max(3,Math.min(9,CursorLightRenderer.dotSize+2));
        for(int i=0;i<12;i++){double a=i*Math.PI/6;int x=cx+(int)Math.round(Math.cos(a)*24),y=cy+(int)Math.round(Math.sin(a)*24);g.fill(x,y,x+dot,y+dot,CursorLightRenderer.glowColor);}
        g.fill(cx-4,cy-4,cx+5,cy+5,CursorLightRenderer.glowColor);
        g.text(font,"LIVE PREVIEW",contentX+88,contentY+43,0xFFE8F0FA);
        g.text(font,CursorLightRenderer.cursorLightEnabled?"LIGHT IS ACTIVE":"LIGHT IS DISABLED",contentX+88,contentY+63,CursorLightRenderer.cursorLightEnabled?0xFF91A5BF:0xFFFFB3A8);
        g.text(font,"Adjust radius and intensity below.",contentX+88,contentY+83,0xFF91A5BF);
    }
    private void drawLayout(GuiGraphicsExtractor g){
        g.text(font,"LAYOUT & DENSITY",contentX,contentY,0xFFD7E4F5);
        g.text(font,"Menu scale changes the ring size; dot spacing controls density.",contentX,contentY+157,0xFFA9BBD1);
    }

    private static float next(float current,float[] values,int direction){int i=0;for(int j=0;j<values.length;j++)if(Math.abs(current-values[j])<.001f)i=j;return values[Math.floorMod(i+direction,values.length)];}
    private static int next(int current,int[] values,int direction){int i=0;for(int j=0;j<values.length;j++)if(current==values[j])i=j;return values[Math.floorMod(i+direction,values.length)];}
    private static float clamp(float v){return Math.max(0,Math.min(1,v));}
    private static String percent(float v){return String.format(Locale.ROOT,"%.0f%%",v*100);}
    private static boolean contains(int x,int y,int w,int h,double px,double py){return px>=x&&px<x+w&&py>=y&&py<y+h;}
    private static void roundedFill(GuiGraphicsExtractor g,int x,int y,int w,int h,int r,int color){
        if(w<=0||h<=0)return;g.fill(x,y,x+w,y+h,color);
    }
    private static void roundedGradient(GuiGraphicsExtractor g,int x,int y,int w,int h,int radius,int top,int bottom){
        if(w<=0||h<=0)return;g.fillGradient(x,y,x+w,y+h,top,bottom);g.outline(x,y,w,h,0x3D8CBAE8);
    }

    private enum Page{OVERVIEW("OVERVIEW"),COLORS("COLORS"),GLASS("GLASS"),CURSOR("CURSOR LIGHT"),LAYOUT("LAYOUT");private final String label;Page(String s){label=s;}}
    private enum ColorTarget{BUTTONS("BUTTONS"),CURSOR("CURSOR"),ACCENT("ACCENT");private final String label;ColorTarget(String s){label=s;}}
    private record Theme(String name,int button,int cursor,int accent){}
}
