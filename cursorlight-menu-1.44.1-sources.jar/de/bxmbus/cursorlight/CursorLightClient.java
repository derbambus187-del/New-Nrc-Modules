package de.bxmbus.cursorlight;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.screens.Screen;
import com.mojang.blaze3d.platform.InputConstants;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class CursorLightClient implements ClientModInitializer {
    private static final Logger LOGGER = LoggerFactory.getLogger("CursorLight");
    public static float menuScale = 1.0f;
    /** 0 = off, 1 = title screen only, 2 = all menu screens. */
    public static int liquidGlassMode = 2;
    public static int glassPreset = 1;
    private static final Path CONFIG = FabricLoader.getInstance().getConfigDir().resolve("bxmbus-cursor-light.properties");
    private static KeyMapping openSettingsKey;

    @Override
    public void onInitializeClient() {
        GlassRenderPipelines.initialize();
        // This is a fallback for the standalone profile. If either client UI owns
        // Right Shift, leave that binding alone so the two menus never compete.
        if (!FabricLoader.getInstance().isModLoaded("derbxmbus_client")
                && !FabricLoader.getInstance().isModLoaded("nrcclient")) {
            openSettingsKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                    "key.bxmbus_cursor_light.open_config", InputConstants.Type.KEYSYM,
                    344, KeyMapping.Category.MISC));
            net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.END_CLIENT_TICK.register(client -> {
                if (openSettingsKey.consumeClick()
                        && !(client.gui.screen() instanceof CursorLightConfigScreen)) {
                    Screen parent = client.gui.screen();
                    client.setScreenAndShow(new CursorLightConfigScreen(parent));
                }
            });
        }
        Properties properties = new Properties();
        if (Files.exists(CONFIG)) {
            try (var reader = Files.newBufferedReader(CONFIG)) {
                properties.load(reader);
                CursorLightRenderer.buttonColor = (int) Long.parseLong(properties.getProperty("buttonColor", "665A6A8A"), 16);
                CursorLightRenderer.glowColor = (int) Long.parseLong(properties.getProperty("glowColor", "FFB8D9FF"), 16);
                CursorLightRenderer.accentColor = (int) Long.parseLong(properties.getProperty("accentColor", "FF68D4FF"), 16);
                CursorLightRenderer.glassOpacityLevel = Math.max(0, Math.min(7,
                        Integer.parseInt(properties.getProperty("glassOpacityLevel", "3"))));
                CursorLightRenderer.cursorLightEnabled = Boolean.parseBoolean(
                        properties.getProperty("cursorLightEnabled", "true"));
                CursorLightRenderer.cursorRadius = clamp(Float.parseFloat(properties.getProperty("cursorRadius", "112")), 56.0f, 220.0f);
                CursorLightRenderer.cursorIntensity = clamp(Float.parseFloat(properties.getProperty("cursorIntensity", "1.0")), 0.25f, 1.5f);
                CursorLightRenderer.gridSpacing = Math.max(8, Math.min(36, Integer.parseInt(properties.getProperty("gridSpacing", "18"))));
                CursorLightRenderer.dotSize = Math.max(1, Math.min(6, Integer.parseInt(properties.getProperty("dotSize", "2"))));
                CursorLightRenderer.hoverScale = clamp(Float.parseFloat(properties.getProperty("hoverScale", "0.035")), 0.0f, 0.12f);
                menuScale = Math.max(0.65f, Math.min(1.45f, Float.parseFloat(properties.getProperty("menuScale", "1.0"))));
                String mode = properties.getProperty("liquidGlassMode");
                if (mode != null) {
                    liquidGlassMode = Math.max(0, Math.min(2, Integer.parseInt(mode)));
                } else {
                    // Upgrade the previous on/off setting without changing existing user preference.
                    liquidGlassMode = Boolean.parseBoolean(properties.getProperty("shaderEffectsEnabled", "true")) ? 2 : 0;
                }
                glassPreset = Math.max(0, Math.min(3, Integer.parseInt(properties.getProperty("glassPreset", "1"))));
            } catch (IOException | NumberFormatException ignored) {
                // Use defaults when a configuration file is missing or invalid.
            }
        }
        LOGGER.info("Liquid-glass mode: {} (config: {})", liquidGlassMode, CONFIG);
    }

    public static void saveConfig() {
        Properties properties = new Properties();
        properties.setProperty("buttonColor", String.format("%08X", CursorLightRenderer.buttonColor));
        properties.setProperty("glowColor", String.format("%08X", CursorLightRenderer.glowColor));
        properties.setProperty("accentColor", String.format("%08X", CursorLightRenderer.accentColor));
        properties.setProperty("glassOpacityLevel", Integer.toString(CursorLightRenderer.glassOpacityLevel));
        properties.setProperty("cursorLightEnabled", Boolean.toString(CursorLightRenderer.cursorLightEnabled));
        properties.setProperty("cursorRadius", Float.toString(CursorLightRenderer.cursorRadius));
        properties.setProperty("cursorIntensity", Float.toString(CursorLightRenderer.cursorIntensity));
        properties.setProperty("gridSpacing", Integer.toString(CursorLightRenderer.gridSpacing));
        properties.setProperty("dotSize", Integer.toString(CursorLightRenderer.dotSize));
        properties.setProperty("hoverScale", Float.toString(CursorLightRenderer.hoverScale));
        properties.setProperty("menuScale", Float.toString(menuScale));
        properties.setProperty("liquidGlassMode", Integer.toString(liquidGlassMode));
        properties.setProperty("glassPreset", Integer.toString(glassPreset));
        try {
            Files.createDirectories(CONFIG.getParent());
            try (var writer = Files.newBufferedWriter(CONFIG)) { properties.store(writer, "Bxmbus Cursor Light"); }
        } catch (IOException ignored) {
            // The current session still uses the selected values.
        }
    }

    public static boolean glassForTitle() { return liquidGlassMode != 0; }
    public static boolean glassForOtherMenus() { return liquidGlassMode == 2; }

    public static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
