package de.bxmbus.cursorlight;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

/** Optional Mod Menu integration for the Cursor Light design screen. */
public final class CursorLightModMenuApi implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return CursorLightConfigScreen::new;
    }
}
