package de.bxmbus.cursorlight.mixin;

import de.bxmbus.cursorlight.CursorLightRenderer;
import de.bxmbus.cursorlight.CursorLightClient;
import de.bxmbus.cursorlight.GlassBackdrop;
import de.bxmbus.cursorlight.MenuPlayerSkin;
import com.mojang.realmsclient.gui.screens.RealmsNotificationsScreen;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.SplashRenderer;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Adds the cursor-light background to the title screen, below its widgets. */
@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin {
    @Unique private static final Logger bxmbus$logger = LoggerFactory.getLogger("CursorLight/TitleScreen");
    @Unique private static boolean bxmbus$loggedInit;
    @Unique private static boolean bxmbus$loggedBackground;
    @Unique private static Model.Simple bxmbus$headModel;
    @Unique private static ModelPart bxmbus$headRoot;

    @Shadow private RealmsNotificationsScreen realmsNotificationsScreen;
    @Shadow private SplashRenderer splash;

    @Inject(method = "init", at = @At("TAIL"))
    private void bxmbus$addDesignMenu(CallbackInfo ci) {
        Screen screen = (Screen) (Object) this;
        // The vanilla notification overlay adds two status badges over the Realms button.
        realmsNotificationsScreen = null;
        // Do not select or render any of the randomized vanilla splash messages.
        splash = null;
        CursorLightRenderer.configureRadialMenu(screen.width, screen.height, 0);
        int ringQuadSize = CursorLightRenderer.ringDiameter;
        int ringQuadX = CursorLightRenderer.ringQuadX();
        int ringQuadY = CursorLightRenderer.ringQuadY();
        CursorLightRenderer.resetRadialHoverAnimation();
        if (!bxmbus$loggedInit) {
            bxmbus$loggedInit = true;
            bxmbus$logger.info("Title-screen mixin initialized; radial menu active ({}x{}, scale={})",
                    screen.width, screen.height, CursorLightRenderer.menuScaleForGui());
        }
        ((ScreenAccessor) (Object) screen).bxmbus$addRenderableWidget(Button.builder(
                Component.literal("MODS"), button -> net.minecraft.client.Minecraft.getInstance()
                        .setScreenAndShow(new de.bxmbus.cursorlight.CursorLightConfigScreen(screen)))
                .bounds(ringQuadX, ringQuadY, ringQuadSize, ringQuadSize).build());
        List<? extends net.minecraft.client.gui.components.events.GuiEventListener> widgets = screen.children();
        for (var child : widgets) {
            if (!(child instanceof AbstractWidget widget)) continue;
            String label = widget.getMessage().getString().toLowerCase(java.util.Locale.ROOT);
            if (label.contains("accessib") || label.contains("language") || label.contains("narrator")
                    || label.contains("friend") || label.contains("freund")) {
                widget.visible = false;
                continue;
            }
            int slot = CursorLightRenderer.radialMenuSlot(label);
            if (slot < 0) continue;
            widget.setTooltip(null);
            // All six visible segments are clipped from the same square around the head;
            // the widget hit-test mixin routes interaction to the actual annular sector.
            widget.setWidth(ringQuadSize);
            widget.setHeight(ringQuadSize);
            widget.setX(ringQuadX);
            widget.setY(ringQuadY);
        }
    }

    @Inject(method = "extractBackground", at = @At("TAIL"))
    private void bxmbus$cursorLight(GuiGraphicsExtractor graphics, int mouseX, int mouseY,
                                    float delta, CallbackInfo ci) {
        CursorLightRenderer.render(graphics, mouseX, mouseY);
        CursorLightRenderer.glassUiActive = CursorLightClient.glassForTitle();
        if (CursorLightClient.glassForTitle()) GlassBackdrop.markAfterScreenBackground(graphics);
        if (!bxmbus$loggedBackground) {
            bxmbus$loggedBackground = true;
            bxmbus$logger.info("Title-screen background hook active; glass UI enabled");
        }
    }

    @Inject(method = "extractRenderState", at = @At("TAIL"))
    private void bxmbus$removeBrandingAndDrawAvatar(GuiGraphicsExtractor graphics, int mouseX, int mouseY,
                                                    float delta, CallbackInfo ci) {
        var minecraft = net.minecraft.client.Minecraft.getInstance();
        int width = graphics.guiWidth(), height = graphics.guiHeight();
        int bottomClear = Math.max(0, height - 22);
        graphics.fill(0, bottomClear, width, height, 0xFF050505);
        CursorLightRenderer.renderDotsBetween(graphics, mouseX, mouseY, bottomClear, height);

        var skin = MenuPlayerSkin.get();
        if (skin != null) {
            int size = Math.round(58 * CursorLightRenderer.menuScaleForGui());
            int centerX = width / 2, centerY = height / 2;
            // The head's projected width grows while it turns sideways. Give the preview
            // extra transparent margin so the rotated skin does not get clipped by its PIP.
            int previewWidth = Math.round(size * 1.8f);
            int previewHeight = Math.round(size * 2.2f);
            int x0 = centerX - previewWidth / 2, x1 = centerX + previewWidth / 2;
            int y0 = centerY - previewHeight / 2, y1 = centerY + previewHeight / 2;
            float modelScale = Math.max(1.0f, size * 0.97f / 2.125f * 4.0f);
            if (bxmbus$headModel == null) {
                ModelPart player = minecraft.getEntityModels().bakeLayer(ModelLayers.PLAYER);
                ModelPart head = player.getChild("head");
                ModelPart hat = head.getChild("hat");
                hat.visible = true;
                // Reparent only the head below a pivot at its geometric center.
                // This avoids the GUI preview's whole-model pivot shifting the head as it tilts.
                head.setPos(0.0f, 4.0f, 0.0f);
                bxmbus$headRoot = new ModelPart(List.of(), Map.of("head", head));
                bxmbus$headModel = new Model.Simple(bxmbus$headRoot, RenderTypes::entityTranslucent);
            }
            double focalX = Math.max(1.0, width * 0.5);
            double focalY = Math.max(1.0, height * 0.5);
            float yaw = (float) Math.toDegrees(Math.atan2(mouseX - centerX, focalX));
            float pitch = (float) Math.toDegrees(Math.atan2(mouseY - centerY, focalY));
            pitch = Math.max(-35.0f, Math.min(35.0f, pitch));
            float pitchRadians = (float) Math.toRadians(pitch);
            // Keep the geometric center of the head fixed; pitch and yaw rotate
            // around this center instead of compensating toward the front face.
            float rootY = 16.0f * (1.601f - previewHeight / (2.0f * modelScale));
            bxmbus$headRoot.setPos(0.0f, rootY, 0.0f);
            bxmbus$headRoot.xRot = pitchRadians;
            bxmbus$headRoot.yRot = (float) Math.toRadians(-yaw);
            graphics.skin(bxmbus$headModel, skin.body().texturePath(), modelScale,
                    0.0f, 0.0f, 0.0f, x0, y0, x1, y1);
        }
    }
}
