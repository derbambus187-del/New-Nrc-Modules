package de.bxmbus.cursorlight.mixin;

import de.bxmbus.cursorlight.GlassWidgets;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractSelectionList;
import net.minecraft.client.gui.components.AbstractWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractSelectionList.class)
public abstract class SelectionListGlassMixin {
    @Inject(method = "extractListBackground", at = @At("HEAD"), cancellable = true)
    private void cursorlight$glassList(GuiGraphicsExtractor graphics, CallbackInfo ci) {
        AbstractWidget list = (AbstractWidget) (Object) this;
        if (GlassWidgets.panel(graphics, list.getX(), list.getY(), list.getWidth(), list.getHeight())) ci.cancel();
    }
}
