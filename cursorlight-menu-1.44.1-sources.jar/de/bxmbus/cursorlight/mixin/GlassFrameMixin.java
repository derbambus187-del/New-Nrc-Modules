package de.bxmbus.cursorlight.mixin;

import de.bxmbus.cursorlight.GlassBackdrop;
import de.bxmbus.cursorlight.GlassWidgets;
import net.minecraft.client.renderer.state.gui.GuiRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GuiRenderState.class)
public abstract class GlassFrameMixin {
    @Inject(method = "reset", at = @At("HEAD"))
    private void cursorlight$resetGlassFrame(CallbackInfo ci) {
        GlassBackdrop.resetFrame();
        GlassWidgets.resetFrame();
    }
}
