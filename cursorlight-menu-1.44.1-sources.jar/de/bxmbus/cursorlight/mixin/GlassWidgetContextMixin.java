package de.bxmbus.cursorlight.mixin;

import de.bxmbus.cursorlight.GlassWidgets;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractWidget.class)
public abstract class GlassWidgetContextMixin {
    @Inject(method = "extractRenderState", at = @At("HEAD"))
    private void cursorlight$beginWidget(GuiGraphicsExtractor graphics, int mouseX, int mouseY,
                                         float delta, CallbackInfo ci) {
        GlassWidgets.beginWidget((AbstractWidget) (Object) this);
    }

    @Inject(method = "extractRenderState", at = @At("RETURN"))
    private void cursorlight$endWidget(GuiGraphicsExtractor graphics, int mouseX, int mouseY,
                                       float delta, CallbackInfo ci) {
        GlassWidgets.endWidget();
    }
}
