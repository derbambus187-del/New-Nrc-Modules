package de.bxmbus.cursorlight.mixin;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.LogoRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Keeps the vanilla title and edition textures from being submitted on the title screen. */
@Mixin(LogoRenderer.class)
public abstract class LogoRendererMixin {
    @Inject(
            method = "extractRenderState(Lnet/minecraft/client/gui/GuiGraphicsExtractor;IF)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void bxmbus$hideVanillaTitleTextures(GuiGraphicsExtractor graphics, int screenWidth,
                                                  float alpha, CallbackInfo ci) {
        ci.cancel();
    }
}
