package de.bxmbus.cursorlight.mixin;

import de.bxmbus.cursorlight.GlassWidgets;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.PlayerTabOverlay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(PlayerTabOverlay.class)
public abstract class PlayerTabGlassMixin {
    @Redirect(method = "extractRenderState", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;fill(IIIII)V"))
    private void cursorlight$tabPanel(GuiGraphicsExtractor graphics,
                                     int left, int top, int right, int bottom, int color) {
        if (!GlassWidgets.panel(graphics, left, top, right - left, bottom - top)) {
            graphics.fill(left, top, right, bottom, color);
        }
    }
}
