package de.bxmbus.cursorlight.mixin;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import de.bxmbus.cursorlight.GlassWidgets;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GuiGraphicsExtractor.class)
public abstract class GuiGlassSpriteMixin {
    // The color overload is the common destination of the normal and alpha overloads.
    @Inject(method = "blitSprite(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIIII)V",
            at = @At("HEAD"), cancellable = true)
    private void cursorlight$glassSprite(RenderPipeline pipeline, Identifier sprite,
                                         int x, int y, int width, int height, int color, CallbackInfo ci) {
        if (GlassWidgets.replaceSprite((GuiGraphicsExtractor) (Object) this,
                sprite, x, y, width, height, color)) ci.cancel();
    }
}
