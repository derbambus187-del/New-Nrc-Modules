package de.bxmbus.cursorlight.mixin;

import de.bxmbus.cursorlight.GlassWidgets;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(targets = "net.minecraft.client.gui.components.tabs.MenuTabBar$MenuTabButton")
public abstract class TabGlassMixin {
    @Inject(method = "renderMenuBackground", at = @At("HEAD"), cancellable = true)
    private void cursorlight$keepSelectedTabGlass(GuiGraphicsExtractor graphics,
                                                 int left, int top, int right, int bottom, CallbackInfo ci) {
        if (GlassWidgets.enabled()) ci.cancel();
    }
}
