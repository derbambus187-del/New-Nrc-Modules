package de.bxmbus.cursorlight.mixin;

import de.bxmbus.cursorlight.GlassBackdrop;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Keeps the captured menu background sharp while still using Minecraft's GUI stratum boundary. */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "processBlurEffect", at = @At("HEAD"), cancellable = true)
    private void cursorlight$skipBlurForGlassCapture(CallbackInfo ci) {
        if (GlassBackdrop.capturePending()) ci.cancel();
    }
}
