package de.bxmbus.cursorlight.mixin;

import de.bxmbus.cursorlight.CursorLightRenderer;
import net.minecraft.client.gui.components.AbstractWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractWidget.class)
public abstract class RadialMenuWidgetMixin {
    @Inject(method = "isMouseOver", at = @At("HEAD"), cancellable = true)
    private void bxmbus$radialSegmentHitTest(double mouseX, double mouseY,
                                              CallbackInfoReturnable<Boolean> cir) {
        if (!CursorLightRenderer.radialMenuActive) return;

        AbstractWidget widget = (AbstractWidget) (Object) this;
        // Minecraft's ContainerEventHandler hit-tests every child, including hidden
        // widgets. Old-page proxies and hidden source buttons must not eat clicks.
        if (!widget.visible) {
            cir.setReturnValue(false);
            return;
        }
        int slot = CursorLightRenderer.radialMenuSlot(widget);
        if (slot < 0) return;

        cir.setReturnValue(CursorLightRenderer.isPointInRadialSlot(mouseX, mouseY, slot));
    }
}
