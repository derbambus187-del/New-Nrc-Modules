package de.bxmbus.cursorlight.mixin;

import de.bxmbus.cursorlight.CursorLightClient;
import de.bxmbus.cursorlight.CursorLightRenderer;
import de.bxmbus.cursorlight.GlassBackdrop;
import de.bxmbus.cursorlight.PauseRadialMenu;
import de.bxmbus.cursorlight.MenuPlayerSkin;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.world.entity.player.PlayerSkin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import java.util.Map;

@Mixin(PauseScreen.class)
public abstract class PauseScreenMixin {
    @Unique private static Model.Simple cursorlight$headModel;
    @Unique private static ModelPart cursorlight$headRoot;

    @Inject(method = "init", at = @At("TAIL"))
    private void cursorlight$resetPauseRadialMenu(CallbackInfo ci) {
        PauseRadialMenu.reset((PauseScreen) (Object) this);
    }

    @Inject(method = "extractRenderState", at = @At("HEAD"))
    private void cursorlight$installPauseRadialMenu(GuiGraphicsExtractor graphics,
                                                     int mouseX, int mouseY, float delta,
                                                     CallbackInfo ci) {
        PauseScreen screen = (PauseScreen) (Object) this;
        PauseRadialMenu.ensureInstalled(screen, graphics.guiWidth(), graphics.guiHeight());
    }

    @Inject(method = "extractBackground", at = @At("TAIL"))
    private void cursorlight$markPauseGlassBoundary(GuiGraphicsExtractor graphics, int mouseX, int mouseY,
                                                    float delta, CallbackInfo ci) {
        CursorLightRenderer.glassUiActive = CursorLightClient.glassForOtherMenus();
        if (CursorLightClient.glassForOtherMenus()) GlassBackdrop.markAfterScreenBackground(graphics);
    }

    @Inject(method = "extractRenderState", at = @At("TAIL"))
    private void cursorlight$drawPlayerHead(GuiGraphicsExtractor graphics, int mouseX, int mouseY,
                                             float delta, CallbackInfo ci) {
        Screen screen = (Screen) (Object) this;
        if (!PauseRadialMenu.isInstalled(screen)) return;
        var minecraft = net.minecraft.client.Minecraft.getInstance();
        PlayerSkin skin = MenuPlayerSkin.get();
        if (skin == null) return;

        int width = graphics.guiWidth(), height = graphics.guiHeight();
        int size = Math.round(58 * CursorLightRenderer.menuScaleForGui());
        int previewWidth = Math.round(size * 1.8f), previewHeight = Math.round(size * 2.2f);
        int centerX = width / 2, centerY = height / 2;
        int x0 = centerX - previewWidth / 2, x1 = centerX + previewWidth / 2;
        int y0 = centerY - previewHeight / 2, y1 = centerY + previewHeight / 2;
        float modelScale = Math.max(1.0f, size * 0.97f / 2.125f * 4.0f);
        if (cursorlight$headModel == null) {
            ModelPart player = minecraft.getEntityModels().bakeLayer(ModelLayers.PLAYER);
            ModelPart head = player.getChild("head");
            head.getChild("hat").visible = true;
            head.setPos(0.0f, 4.0f, 0.0f);
            cursorlight$headRoot = new ModelPart(List.of(), Map.of("head", head));
            cursorlight$headModel = new Model.Simple(cursorlight$headRoot, RenderTypes::entityTranslucent);
        }
        float yaw = (float) Math.toDegrees(Math.atan2(mouseX - centerX, Math.max(1.0, width * 0.5)));
        float pitch = (float) Math.toDegrees(Math.atan2(mouseY - centerY, Math.max(1.0, height * 0.5)));
        pitch = Math.max(-35.0f, Math.min(35.0f, pitch));
        float pitchRadians = (float) Math.toRadians(pitch);
        float rootY = 16.0f * (1.601f - previewHeight / (2.0f * modelScale));
        cursorlight$headRoot.setPos(0.0f, rootY, 0.0f);
        cursorlight$headRoot.xRot = pitchRadians;
        cursorlight$headRoot.yRot = (float) Math.toRadians(-yaw);
        graphics.skin(cursorlight$headModel, skin.body().texturePath(), modelScale,
                0.0f, 0.0f, 0.0f, x0, y0, x1, y1);
        if (PauseRadialMenu.isExtrasPage(screen)) {
            graphics.centeredText(minecraft.font, "BACK", centerX, centerY + size / 2 + 7, 0xFFF3F7FF);
        }
    }
}
