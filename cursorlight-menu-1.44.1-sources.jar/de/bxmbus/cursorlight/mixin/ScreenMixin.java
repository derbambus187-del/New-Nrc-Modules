package de.bxmbus.cursorlight.mixin;

import de.bxmbus.cursorlight.CursorLightRenderer;
import de.bxmbus.cursorlight.CursorLightClient;
import de.bxmbus.cursorlight.GlassBackdrop;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Keeps the existing cursor-light backdrop and enables glass on ordinary menu buttons. */
@Mixin(Screen.class)
public abstract class ScreenMixin {
    @Inject(method = "extractBlurredBackground", at = @At("HEAD"), cancellable = true)
    private void bxmbus$moveBlurAfterBackground(GuiGraphicsExtractor graphics, CallbackInfo ci) {
        boolean eligible = (Object) this instanceof TitleScreen
                ? CursorLightClient.glassForTitle() : CursorLightClient.glassForOtherMenus();
        if (eligible && !((Object) this instanceof AbstractContainerScreen<?>)) {
            // Move the vanilla blur split to the tail hook so the copied texture
            // contains the completed screen background rather than an earlier frame.
            ci.cancel();
        }
    }

    @Inject(method = "extractBackground", at = @At("TAIL"))
    private void bxmbus$cursorLightInMenus(GuiGraphicsExtractor graphics, int mouseX, int mouseY,
                                            float delta, CallbackInfo ci) {
        // PauseScreen has its own ring-menu lifecycle and background capture hook.
        // Letting this generic hook clear radialMenuActive breaks its sector hitboxes
        // and makes the SDF renderer fall back to full rectangular button pills.
        if ((Object) this instanceof TitleScreen || (Object) this instanceof PauseScreen) return;

        CursorLightRenderer.radialMenuActive = false;
        if ((Object) this instanceof AbstractContainerScreen<?>) {
            // Keep the normal in-world background, but let every control/panel on
            // inventories and containers sample it for the all-menus glass scope.
            CursorLightRenderer.glassUiActive = CursorLightClient.glassForOtherMenus();
            if (CursorLightClient.glassForOtherMenus()) GlassBackdrop.markAfterScreenBackground(graphics);
            return;
        }

        CursorLightRenderer.glassUiActive = CursorLightClient.glassForOtherMenus();
        if (Minecraft.getInstance().level == null) {
            CursorLightRenderer.render(graphics, mouseX, mouseY);
        }
        if (CursorLightClient.glassForOtherMenus()) GlassBackdrop.markAfterScreenBackground(graphics);
    }

}
