package de.bxmbus.cursorlight.mixin;

import de.bxmbus.cursorlight.CursorLightClient;
import de.bxmbus.cursorlight.CursorLightRenderer;
import de.bxmbus.cursorlight.LiquidGlassButtonRenderer;
import de.bxmbus.cursorlight.PauseRadialMenu;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.input.MouseButtonEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractButton.class)
public abstract class ButtonMixin {
    private static final Logger LOGGER = LoggerFactory.getLogger("CursorLight/Buttons");
    private static boolean loggedGlassPath;

    @Inject(method = "onClick", at = @At("HEAD"), cancellable = true)
    private void bxmbus$forwardPauseProxyClick(MouseButtonEvent event, boolean doubleClick, CallbackInfo ci) {
        if (PauseRadialMenu.forwardProxyClick((AbstractButton) (Object) this, event, doubleClick)) {
            ci.cancel();
        }
    }

    @Inject(method = "extractWidgetRenderState", at = @At("HEAD"), cancellable = true)
    private void bxmbus$glassButton(GuiGraphicsExtractor graphics, int mouseX, int mouseY,
                                     float delta, CallbackInfo ci) {
        AbstractButton widget = (AbstractButton) (Object) this;
        if (widget.getMessage().getString().equals(PauseRadialMenu.BACK_HITBOX_LABEL)) {
            ci.cancel();
            return;
        }

        int radialSlot = CursorLightRenderer.radialMenuActive
                ? CursorLightRenderer.radialMenuSlot(widget) : -1;
        // Ordinary controls keep their native contents, labels and state icons.
        // Their background sprites are replaced by GuiGlassSpriteMixin instead.
        if (radialSlot < 0) return;
        boolean glassEnabled = CursorLightRenderer.radialMenuContext == 0
                ? CursorLightClient.glassForTitle() : CursorLightClient.glassForOtherMenus();

        int x = widget.getX();
        int y = widget.getY();
        int width = widget.getWidth();
        int height = widget.getHeight();
        if (radialSlot >= 0) {
            // Draw every radial sector from the same screen-space quad used by the
            // hit-test and label geometry; do not trust addon widget bounds here.
            x = CursorLightRenderer.ringQuadX();
            y = CursorLightRenderer.ringQuadY();
            width = CursorLightRenderer.ringDiameter;
            height = CursorLightRenderer.ringDiameter;
        }
        int state = widget.active ? 0 : 128;
        int color = (state << 24) | (CursorLightRenderer.buttonColor & 0x00FFFFFF);
        boolean hovered = radialSlot >= 0
                ? CursorLightRenderer.isPointInRadialSlot(mouseX, mouseY, radialSlot) || widget.isFocused()
                : widget.isHoveredOrFocused();
        float hover = CursorLightRenderer.updateButtonHover(widget, hovered);
        float hoverResponse = CursorLightRenderer.hoverScale <= 0.0f ? 0.0f
                : 0.55f + 0.45f * Math.min(1.0f, CursorLightRenderer.hoverScale / 0.12f);
        hover *= hoverResponse;

        int textX = x + width / 2;
        int textY = y + (height - 8) / 2;
        int availableTextWidth = Math.max(1, width - 12);
        if (radialSlot >= 0) {
            textX = CursorLightRenderer.radialLabelX(radialSlot);
            textY = CursorLightRenderer.radialLabelY(radialSlot);
            availableTextWidth = CursorLightRenderer.radialLabelWidth();
        }

        // Render pause buttons exactly like title-screen buttons: each widget submits
        // its own glass surface using the pose and bounds active for that widget.
        boolean submitted = LiquidGlassButtonRenderer.submit(graphics, x, y, width, height,
                color, radialSlot, hover, glassEnabled);
        if (!submitted) {
            if (radialSlot >= 0) {
                int labelWidth = Minecraft.getInstance().font.width(widget.getMessage());
                int fallbackWidth = Math.min(availableTextWidth, Math.max(104, labelWidth + 24));
                graphics.fill(textX - fallbackWidth / 2, textY - 7,
                        textX + fallbackWidth / 2, textY + 10, 0xDD182235);
                graphics.outline(textX - fallbackWidth / 2, textY - 7,
                        fallbackWidth, 17, 0xFFBED7F2);
                graphics.centeredText(Minecraft.getInstance().font, widget.getMessage(),
                        textX, textY, 0xFFF7FAFF);
                ci.cancel();
            }
            return;
        }

        var font = Minecraft.getInstance().font;
        int labelWidth = font.width(widget.getMessage());
        float labelScale = labelWidth <= 0 ? 1.0f
                : Math.min(1.0f, Math.max(0.45f, (availableTextWidth - 8.0f) / labelWidth));
        if (labelScale < 0.999f) {
            graphics.pose().pushMatrix();
            graphics.pose().translate(textX, textY);
            graphics.pose().scale(labelScale, 1.0f);
            graphics.pose().translate(-textX, -textY);
        }
        graphics.centeredText(font, widget.getMessage(), textX + 1, textY + 1, 0x99303B55);
        graphics.centeredText(font, widget.getMessage(), textX, textY,
                widget.active ? 0xFFF7FAFF : 0xFFB8C2D8);
        if (labelScale < 0.999f) graphics.pose().popMatrix();

        if (radialSlot >= 0 && !loggedGlassPath) {
            loggedGlassPath = true;
            LOGGER.info("Radial menu buttons use stable SDF state with separated hover animation");
        }
        ci.cancel();
    }
}
