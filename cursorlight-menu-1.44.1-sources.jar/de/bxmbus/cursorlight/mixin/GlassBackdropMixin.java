package de.bxmbus.cursorlight.mixin;

import de.bxmbus.cursorlight.GlassBackdrop;
import net.minecraft.client.gui.render.GuiRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GuiRenderer.class)
public abstract class GlassBackdropMixin {
    @Inject(method = "draw", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/GameRenderer;processBlurEffect()V",
            shift = At.Shift.AFTER))
    private void cursorlight$captureBackdrop(CallbackInfo ci) {
        GlassBackdrop.capture();
    }
}
