package de.bxmbus.cursorlight;

import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuSampler;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.render.TextureSetup;
import net.minecraft.client.renderer.state.gui.GuiElementRenderState;
import org.joml.Matrix3x2f;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Adds a texture-free SDF pill whose only sampled image is the copied screen background. */
public final class LiquidGlassButtonRenderer {
    private static final Logger LOGGER = LoggerFactory.getLogger("CursorLight/LiquidGlass");
    private static boolean loggedSubmit;
    private static boolean loggedFallback;

    private LiquidGlassButtonRenderer() {}

    public static boolean submit(GuiGraphicsExtractor graphics, int x, int y, int width, int height,
                                 int color, int radialSlot, float hover, boolean glassEnabled) {
        if (width <= 0 || height <= 0) return false;
        try {
            if (glassEnabled) GlassBackdrop.markAfterScreenBackground(graphics);
            GpuTextureView backdrop = GlassBackdrop.acquire(glassEnabled);
            if (backdrop == null) {
                reportFallback("screen backdrop texture is unavailable");
                return false;
            }
            GpuSampler sampler = RenderSystem.getSamplerCache().getClampToEdge(FilterMode.LINEAR);
            TextureSetup textures = TextureSetup.singleTexture(backdrop, sampler);
            Matrix3x2f pose = new Matrix3x2f(graphics.pose());
            // Extend both the mesh and its declared bounds for the hover expansion.
            // UV0 still describes the unexpanded button, including beyond its edges.
            int padding = Math.max(2, (int) Math.ceil(Math.max(width, height) * 0.012f) + 1);
            ScreenRectangle clip = graphics.scissorStack.peek();
            ScreenRectangle bounds = new ScreenRectangle(x - padding, y - padding,
                    width + padding * 2, height + padding * 2).transformMaxBounds(pose);
            if (clip != null) bounds = bounds.intersection(clip);
            if (bounds == null) return true;
            graphics.guiRenderState.addGuiElement(new GlassButtonState(
                    GlassRenderPipelines.SDF_LIQUID_GLASS_BUTTON, textures, pose,
                    x, y, width, height, padding,
                    encodeState(color, radialSlot, hover, glassEnabled), clip, bounds));
            if (!loggedSubmit) {
                loggedSubmit = true;
                LOGGER.info("Texture-free SDF liquid-glass button pipeline submitted ({}x{})", width, height);
            }
            return true;
        } catch (RuntimeException exception) {
            reportFallback(exception.toString());
            return false;
        }
    }

    private static int encodeState(int color, int radialSlot, float hover, boolean glassEnabled) {
        int slot = radialSlot < 0 ? 7 : radialSlot;
        int oldAlpha = color >>> 24;
        boolean disabled = oldAlpha >= 128;
        int flags = (slot << 5) | (glassEnabled ? 16 : 0) | (disabled ? 8 : 0);
        int red = (color >>> 16) & 0xFF;
        red = (red & 0xFC) | (CursorLightClient.glassPreset & 0x03);
        int green = (color >>> 8) & 0xFF;
        green = (green & 0xF8) | (CursorLightRenderer.glassOpacityLevel & 0x07);
        int blue = color & 0xFF;
        int hoverLevel = Math.max(0, Math.min(15, Math.round(hover * 15.0f)));
        blue = (blue & 0xF0) | hoverLevel;
        // Alpha is reserved for flags: do not OR in the source alpha's disabled bit.
        int tint = (red << 16) | (green << 8) | blue;
        return tint | (flags << 24);
    }

    private static void reportFallback(String reason) {
        if (loggedFallback) return;
        loggedFallback = true;
        LOGGER.warn("Liquid-glass SDF could not be submitted; vanilla button rendering is used: {}", reason);
    }

    private record GlassButtonState(
            com.mojang.blaze3d.pipeline.RenderPipeline pipeline,
            TextureSetup textureSetup,
            Matrix3x2f pose,
            int x,
            int y,
            int width,
            int height,
            int padding,
            int color,
            ScreenRectangle scissorArea,
            ScreenRectangle bounds
    ) implements GuiElementRenderState {
        @Override
        public void buildVertices(VertexConsumer vertices) {
            int left = x - padding, top = y - padding;
            int right = x + width + padding, bottom = y + height + padding;
            float u0 = -(float) padding / width, v0 = -(float) padding / height;
            float u1 = 1.0f - u0, v1 = 1.0f - v0;
            vertices.addVertexWith2DPose(pose, left, top).setUv(u0, v0).setColor(color);
            vertices.addVertexWith2DPose(pose, left, bottom).setUv(u0, v1).setColor(color);
            vertices.addVertexWith2DPose(pose, right, bottom).setUv(u1, v1).setColor(color);
            vertices.addVertexWith2DPose(pose, right, top).setUv(u1, v0).setColor(color);
        }
    }
}
