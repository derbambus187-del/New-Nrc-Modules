package de.bxmbus.cursorlight;

import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import de.bxmbus.cursorlight.mixin.ScreenAccessor;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Folds the five crowded third-party pause buttons into a compact expandable section. */
public final class PauseMenuLayout {
    private static final Logger LOGGER = LoggerFactory.getLogger("CursorLight/PauseMenu");
    private static final Set<Screen> SCANNED = Collections.newSetFromMap(new WeakHashMap<>());
    private static final int HORIZONTAL_GAP = 8;
    private static final int VERTICAL_GAP = 5;
    private PauseMenuLayout() {}

    public static void reset(Screen screen) {
        SCANNED.remove(screen);
    }

    /** Called once after other screen initialization hooks have added their widgets. */
    public static void ensureInstalled(Screen screen) {
        if (!SCANNED.add(screen)) return;
        List<AbstractButton> buttons = new ArrayList<>();
        for (var child : screen.children()) {
            if (child instanceof AbstractButton button && button.visible) buttons.add(button);
        }
        buttons.sort(Comparator.comparingInt(AbstractButton::getY).thenComparingInt(AbstractButton::getX));

        List<List<AbstractButton>> rows = groupRows(buttons);
        List<AbstractButton> crowdedRow = rows.stream()
                .filter(row -> row.size() >= 4 && isCrowded(row))
                .max(Comparator.comparingInt((List<AbstractButton> row) -> row.size())).orElse(null);
        if (crowdedRow == null) return;

        LayoutState state = new LayoutState(screen, rows, crowdedRow);
        Button toggle = Button.builder(Component.literal("MORE OPTIONS  +"), button -> state.toggle())
                .bounds((screen.width - state.optionWidth) / 2, state.originalCenterY - state.toggleHeight / 2,
                        state.optionWidth, state.toggleHeight).build();
        state.toggleButton = toggle;
        state.applyCollapsed();
        ((ScreenAccessor) (Object) screen).bxmbus$addRenderableWidget(toggle);
        LOGGER.info("Installed MORE OPTIONS accordion for {} pause-menu buttons ({}x{})",
                crowdedRow.size(), screen.width, screen.height);
    }

    private static List<List<AbstractButton>> groupRows(List<AbstractButton> buttons) {
        List<List<AbstractButton>> rows = new ArrayList<>();
        for (AbstractButton button : buttons) {
            List<AbstractButton> row = null;
            int centerY = button.getY() + button.getHeight() / 2;
            for (List<AbstractButton> candidate : rows) {
                int rowCenter = candidate.stream().mapToInt(b -> b.getY() + b.getHeight() / 2).sum()
                        / candidate.size();
                if (Math.abs(centerY - rowCenter) <= Math.max(4, button.getHeight() / 3)) {
                    row = candidate;
                    break;
                }
            }
            if (row == null) {
                row = new ArrayList<>();
                rows.add(row);
            }
            row.add(button);
        }
        for (List<AbstractButton> row : rows) row.sort(Comparator.comparingInt(AbstractButton::getX));
        rows.sort(Comparator.comparingInt(row -> row.stream()
                .mapToInt(b -> b.getY() + b.getHeight() / 2).sum() / row.size()));
        return rows;
    }

    private static boolean isCrowded(List<AbstractButton> row) {
        for (AbstractButton button : row) {
            if (Minecraft.getInstance().font.width(button.getMessage()) + 20 > button.getWidth()) return true;
        }
        for (int i = 0; i < row.size(); i++) {
            AbstractButton left = row.get(i);
            for (int j = i + 1; j < row.size(); j++) {
                if (row.get(j).getX() < left.getX() + left.getWidth() - 2) return true;
            }
        }
        return false;
    }

    private static final class LayoutState {
        private final Screen screen;
        private final List<List<AbstractButton>> rows;
        private final List<AbstractButton> optionRow;
        private final List<AbstractButton> options;
        private final List<WidgetBounds> original = new ArrayList<>();
        private final int optionWidth;
        private final int toggleHeight;
        private final int originalCenterY;
        private Button toggleButton;
        private boolean expanded;

        private LayoutState(Screen screen, List<List<AbstractButton>> rows, List<AbstractButton> optionRow) {
            this.screen = screen;
            this.rows = rows;
            this.optionRow = optionRow;
            this.options = List.copyOf(optionRow);
            for (List<AbstractButton> row : rows) for (AbstractButton button : row) {
                original.add(new WidgetBounds(button, button.getX(), button.getY(), button.getWidth(),
                        button.getHeight(), button.active, button.visible));
            }
            toggleHeight = optionRow.stream().mapToInt(AbstractButton::getHeight).max().orElse(20);
            originalCenterY = optionRow.stream().mapToInt(b -> b.getY() + b.getHeight() / 2).sum()
                    / optionRow.size();
            int longest = optionRow.stream().mapToInt(b -> Minecraft.getInstance().font.width(b.getMessage()))
                    .max().orElse(180);
            optionWidth = Math.min(Math.max(140, screen.width - 40), Math.max(220, longest + 32));
        }

        private void toggle() {
            expanded = !expanded;
            if (expanded) applyExpanded();
            else applyCollapsed();
        }

        private void applyCollapsed() {
            restoreOriginalBounds();
            for (AbstractButton option : options) {
                option.visible = false;
                option.active = false;
            }
            toggleButton.setMessage(Component.literal("MORE OPTIONS  +"));
            toggleButton.setSize(optionWidth, toggleHeight);
            toggleButton.setX((screen.width - optionWidth) / 2);
            toggleButton.setY(originalCenterY - toggleHeight / 2);
            toggleButton.visible = true;
            toggleButton.active = true;
        }

        private void applyExpanded() {
            restoreOriginalBounds();
            for (AbstractButton option : options) {
                option.visible = true;
                option.active = originalBounds(option).active;
            }
            toggleButton.setMessage(Component.literal("HIDE OPTIONS  −"));
            toggleButton.setSize(optionWidth, toggleHeight);

            int contentHeight = toggleHeight;
            int rowCount = 1;
            for (List<AbstractButton> row : rows) {
                if (row == optionRow) {
                    for (AbstractButton option : options) contentHeight += option.getHeight();
                    rowCount += options.size();
                } else {
                    contentHeight += row.stream().mapToInt(AbstractButton::getHeight).max().orElse(20);
                    rowCount++;
                }
            }
            int availableHeight = Math.max(80, screen.height - 48);
            int gap = rowCount <= 1 ? 0 : Math.min(VERTICAL_GAP,
                    Math.max(0, (availableHeight - contentHeight) / (rowCount - 1)));
            int totalHeight = contentHeight + gap * Math.max(0, rowCount - 1);
            int y = Math.max(24, (screen.height - totalHeight) / 2);

            for (List<AbstractButton> row : rows) {
                if (row == optionRow) {
                    toggleButton.setX((screen.width - optionWidth) / 2);
                    toggleButton.setY(y);
                    y += toggleHeight + gap;
                    for (AbstractButton option : options) {
                        option.setWidth(optionWidth);
                        option.setX((screen.width - optionWidth) / 2);
                        option.setY(y);
                        y += option.getHeight() + gap;
                    }
                } else {
                    int rowHeight = row.stream().mapToInt(AbstractButton::getHeight).max().orElse(20);
                    int rowWidth = row.stream().mapToInt(AbstractButton::getWidth).sum()
                            + HORIZONTAL_GAP * (row.size() - 1);
                    int x = (screen.width - rowWidth) / 2;
                    for (AbstractButton button : row) {
                        button.setX(x);
                        button.setY(y + (rowHeight - button.getHeight()) / 2);
                        x += button.getWidth() + HORIZONTAL_GAP;
                    }
                    y += rowHeight + gap;
                }
            }
        }

        private void restoreOriginalBounds() {
            for (WidgetBounds bounds : original) {
                bounds.button.setRectangle(bounds.x, bounds.y, bounds.width, bounds.height);
                bounds.button.active = bounds.active;
                bounds.button.visible = bounds.visible;
            }
        }

        private WidgetBounds originalBounds(AbstractButton button) {
            return original.stream().filter(bounds -> bounds.button == button).findFirst().orElseThrow();
        }
    }

    private record WidgetBounds(AbstractButton button, int x, int y, int width, int height,
                                boolean active, boolean visible) {}
}
