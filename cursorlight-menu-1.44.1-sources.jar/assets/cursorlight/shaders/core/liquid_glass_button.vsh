#version 330

// Minecraft 26.2 GUI vertex contract: Position, UV0 and Color.
// UV0 is local 0..1 pill space, not a button image lookup.
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

in vec3 Position;
in vec2 UV0;
in vec4 Color;

out vec2 localUv;
out vec4 buttonState;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    localUv = UV0;
    buttonState = Color;
}
