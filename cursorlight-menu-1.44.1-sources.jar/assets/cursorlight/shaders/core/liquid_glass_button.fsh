#version 330

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};

uniform sampler2D Sampler0; // Sharp framebuffer copy from immediately before the button stratum.
in vec2 localUv;
in vec4 buttonState; // RGB packs tint/preset/opacity/hover; A packs only shape slot and flags.
out vec4 fragColor;

// Visual tuning (screen pixels unless otherwise noted).
const float CORNER_RADIUS = 1.00;       // A pill has a radius equal to half its height.
const float EDGE_SOFTNESS_PX = 1.0;
const float RIM_WIDTH_PX = 1.2;
const float REFRACTION_PIXELS = 7.0;
const float CHROMATIC_DISPERSION = 0.075;
const float TINT_STRENGTH = 0.13;
const float SATURATION_BOOST = 1.10;
const float HOVER_BRIGHTNESS = 0.18;
const float HOVER_REFRACTION_BOOST = 0.34;
const float HOVER_GLOSS_BOOST = 0.42;
const float GLASS_OPACITY = 0.68;
const float EDGE_OPACITY_BOOST = 0.16;
const float KEY_GLOSS_STRENGTH = 0.62;
const float FILL_GLOSS_STRENGTH = 0.18;
const float UPPER_SHEEN_STRENGTH = 0.075;
const float CONTOUR_STRENGTH = 0.38;
const float RING_INNER_RATIO = 0.54;
const float RING_OUTER_RATIO = 0.98;
const float SECTOR_HALF_ANGLE = 0.5 * 1.0471975512 - 0.0261799388; // 30 degrees less a 1.5-degree gap.
const vec2 LIGHT_DIRECTION_TOP_LEFT = vec2(-0.577, -0.816);
const float PI = 3.14159265359;

float roundedRectSdf(vec2 p, vec2 halfSize, float radius) {
    vec2 q = abs(p) - halfSize + radius;
    return length(max(q, vec2(0.0))) + min(max(q.x, q.y), 0.0) - radius;
}

float roundedSectorSdf(vec2 p, float halfRadius, float slot) {
    float radius = length(p);
    float outerR = halfRadius * RING_OUTER_RATIO;
    float innerR = halfRadius * RING_INNER_RATIO;
    float ringDistance = max(radius - outerR, innerR - radius);
    float centerAngle = -0.5 * PI + slot * (PI / 3.0);
    float delta = abs(atan(sin(atan(p.y, p.x) - centerAngle), cos(atan(p.y, p.x) - centerAngle)));
    float wedgeDistance = -radius * sin(SECTOR_HALF_ANGLE - delta);
    // The annulus is clipped by the sector edge; the angular margin leaves a visible divider.
    return max(ringDistance, wedgeDistance);
}

void main() {
    vec2 uvDx = vec2(dFdx(localUv.x), dFdy(localUv.x));
    vec2 uvDy = vec2(dFdx(localUv.y), dFdy(localUv.y));
    vec2 quadSize = 1.0 / max(vec2(length(uvDx), length(uvDy)), vec2(1e-6));
    vec2 p = (localUv - vec2(0.5)) * quadSize;
    vec2 halfSize = quadSize * 0.5;

    int packedState = int(floor(buttonState.a * 255.0 + 0.5));
    int slot = packedState >> 5;
    bool glassEnabled = (packedState & 16) != 0;
    bool disabled = (packedState & 8) != 0;
    int blueByte = int(floor(buttonState.b * 255.0 + 0.5));
    float hover = float(blueByte & 15) / 15.0;

    float sdfDistance;
    if (slot < 6) {
        // A tiny radial expansion makes hover feel tactile while the fixed angular
        // edges preserve the gaps between sectors.
        sdfDistance = roundedSectorSdf(p, min(halfSize.x, halfSize.y) * (1.0 + 0.018 * hover), float(slot));
    } else {
        // Slot 6 is reserved for larger menu panels; those keep fixed bounds.
        vec2 hoverHalfSize = halfSize * (1.0 + (slot == 6 ? 0.0 : 0.018) * hover);
        sdfDistance = roundedRectSdf(p, hoverHalfSize,
                slot == 6 ? min(min(hoverHalfSize.x, hoverHalfSize.y), 12.0)
                          : min(hoverHalfSize.y * CORNER_RADIUS, hoverHalfSize.x));
    }

    float antialias = max(fwidth(sdfDistance) * EDGE_SOFTNESS_PX, 1e-4);
    float coverage = 1.0 - smoothstep(-antialias, antialias, sdfDistance);
    if (coverage <= 0.001) discard;

    // The configured look preset rides in the red channel's two least-significant bits.
    // Losing at most two red levels keeps tint colors visually unchanged.
    int redByte = int(floor(buttonState.r * 255.0 + 0.5));
    int glassPreset = redByte & 3;
    float cleanRed = float((redByte & 252) + 2) / 255.0;
    int greenByte = int(floor(buttonState.g * 255.0 + 0.5));
    int opacityLevel = greenByte & 7;
    float cleanGreen = float((greenByte & 248) + 4) / 255.0;
    float cleanBlue = float((blueByte & 240) + 8) / 255.0;
    float configuredOpacity = 0.56 + float(opacityLevel) * 0.04;
    vec3 tint = vec3(cleanRed, cleanGreen, cleanBlue) * ColorModulator.rgb;
    float effectGain = 0.62 + float(glassPreset) * 0.34;
    if (!glassEnabled) {
        // Liquid Glass OFF still preserves the title ring's segment geometry as a plain tinted surface.
        vec3 flatColor = mix(tint * 0.78, tint * 1.06, clamp(localUv.y * 0.75 + 0.15, 0.0, 1.0));
        float edgeLine = 1.0 - smoothstep(0.0, antialias * 1.7, abs(sdfDistance));
        flatColor += vec3(0.10) * edgeLine;
        if (disabled) flatColor *= 0.58;
        fragColor = vec4(clamp(flatColor, 0.0, 1.0), coverage * configuredOpacity * ColorModulator.a);
        return;
    }

    vec2 gradient = vec2(dFdx(sdfDistance), dFdy(sdfDistance));
    vec2 normal = gradient / max(length(gradient), 1e-6);
    float innerDepth = max(-sdfDistance, 0.0);
    float edge = 1.0 - smoothstep(0.0, 18.0, innerDepth);
    float lens = edge * edge * (3.0 - 2.0 * edge);
    vec2 texel = 1.0 / vec2(textureSize(Sampler0, 0));
    vec2 screenUv = gl_FragCoord.xy * texel;
    vec2 offset = -normal * (REFRACTION_PIXELS * effectGain * lens
            * (1.0 + hover * HOVER_REFRACTION_BOOST)) * texel;

    // Sharp single-tap samples: no frosted blur is applied to the background.
    vec3 background;
    background.r = texture(Sampler0, clamp(screenUv + offset * (1.0 - CHROMATIC_DISPERSION * effectGain), vec2(0.001), vec2(0.999))).r;
    background.g = texture(Sampler0, clamp(screenUv + offset, vec2(0.001), vec2(0.999))).g;
    background.b = texture(Sampler0, clamp(screenUv + offset * (1.0 + CHROMATIC_DISPERSION * effectGain), vec2(0.001), vec2(0.999))).b;

    float luminance = dot(background, vec3(0.2126, 0.7152, 0.0722));
    background = mix(vec3(luminance), background, disabled ? 0.52 : SATURATION_BOOST);
    background = mix(background, tint, TINT_STRENGTH);
    background *= disabled ? 0.70 : 1.0;
    background += vec3(HOVER_BRIGHTNESS * hover);

    float rim = 1.0 - smoothstep(0.0, RIM_WIDTH_PX, innerDepth);
    float contour = 1.0 - smoothstep(antialias * 0.45, antialias * 1.7, abs(sdfDistance));
    float keyLight = pow(max(dot(normal, LIGHT_DIRECTION_TOP_LEFT), 0.0), 5.0);
    float softFill = pow(max(dot(normal, -LIGHT_DIRECTION_TOP_LEFT), 0.0), 3.0);
    float upperSheen = exp(-pow((localUv.y - 0.17) / 0.27, 2.0)) * (disabled ? 0.55 : 1.0);
    float gloss = (keyLight * KEY_GLOSS_STRENGTH + softFill * FILL_GLOSS_STRENGTH)
            * (0.78 + 0.14 * float(glassPreset))
            * rim * (1.0 + hover * HOVER_GLOSS_BOOST);
    vec3 color = background + vec3(0.91, 0.97, 1.0)
            * (gloss + contour * CONTOUR_STRENGTH + upperSheen * UPPER_SHEEN_STRENGTH);
    color += tint * rim * 0.07;
    float alpha = coverage * (configuredOpacity + edge * EDGE_OPACITY_BOOST
            + hover * 0.035 + 0.012 * float(glassPreset));
    fragColor = vec4(clamp(color, 0.0, 1.0), alpha * ColorModulator.a);
}

